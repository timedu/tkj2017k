
log = require('../configs/log');
log(module.filename);


// TKJ2017k, Tehtävä 3.3

// Nimi: 
// OppNro: 


const cuid = require('cuid');
const db = require('../configs/db_connection');

const Opettaja = {};
module.exports = Opettaja;


/*
 * SELECT
 */

const sortBy = (p, ar) => {
   return ar.sort((a, b) => {
      return a[p] <= b[p] ? -1 : 1;
   });
};


Opettaja.findAll = (callback) => {

   callback([]);


}; //Opettaja.findAll


Opettaja.findByKey = (key, callback) => {

   callback({});
   return;



   const findKurssitByOpettaja = (key, callback) => {

      const kurssit = [];

      db.kurssit.sublevel(key).createReadStream().on('data', data => {

         const kurssi = data.value;
         kurssi.key = data.key;
         kurssit.push(kurssi);

      }).on('end', () => {

         callback(sortBy('nimi', kurssit));
      });
   }; // findKurssitByOpettaja


}; //Opettaja.findByKey



/*
 * INSERT
 */

Opettaja.create = (opettaja, callback) => {

   callback('');

};


/*
 * UPDATE
 */

Opettaja.update = (opettaja, callback) => {

   callback('');

};


/*
 * DELETE
 */


Opettaja.destroy = (key, callback) => {

   // ...

   db.opettajat.sublevel('del_loki').put(cuid(), {
      opettaja_key: key
   });

   callback();

};


Opettaja.delLoki = (callback) => {

   const poistetut_opettajat = [];

   db.opettajat.sublevel('del_loki').createReadStream().on('data', data => {

      poistetut_opettajat.push(data.value);

   }).on('end', () => {

      callback(poistetut_opettajat);
   });

};