
require('../configs/log')(module.filename);


const db = require('../configs/db_connection');

const Kurssi = {};
module.exports = Kurssi;


/**
 * Lajitelelee oliotaulukon olion ominaisuuden mukaiseen aakkosjärjestykseen
 * @param {String} p ominaisuus, jonka mukaan lajittelu tapahtuu
 * @param {Array} ar lajiteltava taulukko
 * @returns {Array} lajiteltu taulukko
 */
function sortBy(p, ar) {
   return ar.sort((a, b) => {
      return a[p] <= b[p] ? -1 : 1;
   });
}



Kurssi.findAll = (callback) => {

   const kurssit = [];

   db.kurssit.createReadStream().on('data', data => {

      const kurssi = data.value;
      kurssi.key = data.key;
      kurssit.push(kurssi);

   }).on('end', () => {

      callback(sortBy('nimi', kurssit));
   });

}; 


Kurssi.findByKey = (key, callback) => {

   db.kurssit.get(key, (err, kurssi) => {

      kurssi.key = key;

      db.opettajat.get(kurssi.opettaja, (err, opettaja) => {

         kurssi.opettaja = opettaja;
         
         callback(kurssi);
      });

   });

}; 

