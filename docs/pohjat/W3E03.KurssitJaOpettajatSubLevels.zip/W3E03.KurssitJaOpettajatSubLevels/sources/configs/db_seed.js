
/* global __dirname, Promise */

const _log = require('./log');
const log = (msg) => {
   _log(module.filename, msg);
};
log();

const csv = require('csvtojson');
const cuid = require('cuid');

const db = require('./db_connection');


const DataDir = `${__dirname}/db_seed`;

function readOpettajatCSV(resolve, reject) {

   csv({delimiter: ';'}).fromFile(`${DataDir}/opettajat.csv`)
           .on('end_parsed', (objArr) => {
              log('opettaja-data read');
              resolve(objArr);
           })
           .on('error', (err) => {
              reject(err);
           });
}

function readKurssitCSV(resolve, reject) {

   csv({delimiter: ';'}).fromFile(`${DataDir}/kurssit.csv`)
           .on('end_parsed', (objArr) => {
              log('kurssi-data read');
              resolve(objArr);
           })
           .on('error', (err) => {
              reject(err);
           });
}

function ensureOpettajatIsEmpty(resolve, reject) {
   var count = 0;

   db.opettajat.createKeyStream({limit: 1}).on('data', () => {
      count++;
   }).on('end', () => {
      if (!count) {
         resolve();
      } else {
         reject('db.opettajat already contains keys');
      }
   });
}

function ensureKurssitIsEmpty(resolve, reject) {
   var count = 0;

   db.kurssit.createKeyStream({limit: 1}).on('data', () => {
      count++;
   }).on('end', () => {
      if (!count) {
         resolve();
      } else {
         reject('db.kurssit already contains keys');
      }
   });
}



module.exports = () => {

   Promise.all([

      new Promise(ensureOpettajatIsEmpty),
      new Promise(ensureKurssitIsEmpty)

   ]).then(() => {

      Promise.all([

         new Promise(readOpettajatCSV),
         new Promise(readKurssitCSV)

      ]).then(dataArr => {

         const opettajaArr = dataArr[0];
         const opettajaMap = {}; // avaimena tunnus

         opettajaArr.forEach((opettaja) => {
            opettaja.kurssit = {};
            opettaja.key = cuid();
            opettajaMap[opettaja.tunnus] = opettaja;
         });

         const kurssiArr = dataArr[1];
         const kurssiMap = {}; // avaimena cuid

         const batchOps = [];

         kurssiArr.forEach((kurssi) => {

            const kurssiKey = cuid();

            opettajaMap[kurssi.opettaja].kurssit[kurssiKey] = kurssiKey;

            kurssi.opettaja = opettajaMap[kurssi.opettaja].key;

            batchOps.push({
               prefix: db.kurssit,
               key: kurssiKey,
               value: kurssi
            });

            kurssiMap[kurssiKey] = kurssi;
         });

         for (var opettajaTunnus in opettajaMap) {

            batchOps.push({
               prefix: db.opettajat,
               key: opettajaMap[opettajaTunnus].key,
               value: {
                  etunimi: opettajaMap[opettajaTunnus].etunimi,
                  sukunimi: opettajaMap[opettajaTunnus].sukunimi
               }
            });

            var opettajanKurssit = db.kurssit.sublevel(opettajaMap[opettajaTunnus].key);

            for (var kurssiKey in opettajaMap[opettajaTunnus].kurssit) {

               batchOps.push({
                  prefix: opettajanKurssit,
                  key: kurssiKey,
                  value: kurssiMap[kurssiKey]
               });
            }

         }


         db.base.batch(batchOps, {valueEncoding: 'json'}, (err) => {

            if (err) {
               return log('unable to create keys', err);
            }

            log('keys created');

//         dumpDatabase(db.opettajat);
//         dumpDatabase(db.kurssit);
//         dumpOpettajat();

         });

      });

   }, reason => {
      log(reason);
   });

};



//function dumpDatabase(db) {
//
//   db.createReadStream().on('data', function (data) {
//      console.log(data.key, '=', data.value);
//   }).on('error', function (err) {
//      console.log('Oh my!', err);
//   });
//
//}
//
//
//function dumpOpettajat() {
//
//   db.opettajat.createReadStream().on('data', function (data) {
//      console.log(data.key, '=', data.value);
//
//      const opettajanKurssit = db.kurssit.sublevel(data.key);
//
//      opettajanKurssit.createReadStream().on('data', (data) => {
//         console.log(data.key, '=', data.value);
//      });
//
//   }).on('error', function (err) {
//      console.log('Oh my!', err);
//   });
//
//}
