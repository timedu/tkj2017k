
require('./log')(module.filename);

const Level = require('level');
const SubLevel = require('level-sublevel');

const Database = './database/koulu.level';
const levelDB = Level(Database, {valueEncoding: 'json'});
const subLevelDB = SubLevel(levelDB);

const opettajat = subLevelDB.sublevel('opettajat'); 
const kurssit = subLevelDB.sublevel('kurssit'); 

module.exports = {
  base:  subLevelDB,
  opettajat: opettajat,
  kurssit: kurssit
};

