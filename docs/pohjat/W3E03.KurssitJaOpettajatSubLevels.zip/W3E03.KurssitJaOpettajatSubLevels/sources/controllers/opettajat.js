
const log = require('../configs/log');
log(module.filename);

// TKJ2017k, Tehtävä 3.3

// Nimi: 
// OppNro: 


const Opettaja = require('../models/Opettaja');

module.exports = router = require('express').Router();


/*
 * del_loki
 */

router.get('/del_loki', (req, res) => {

   Opettaja.delLoki((poistetut_opettajat) => {

      //log(module.filename, opettajat);

      res.render('del_loki', {
         poistetut_opettajat: poistetut_opettajat
      });

   });
});



/*
 * INSERT
 */

router.get('/insert', (req, res) => {

   res.render('opettaja_insert');
});


router.post('/insert', (req, res) => {

   if (req.body._cancel) {
      res.redirect('/opettajat');
      return;
   }

   delete req.body._insert;
   
   Opettaja.create(req.body, (key) => {
      res.redirect(`/opettajat/${key}`);
   });

});


/*
 * UPDATE
 */


router.get('/:key/update', (req, res) => {

   Opettaja.findByKey(req.params.key, (opettaja) => {

      if (!opettaja) {
         res.render('opettaja_detail');
         return;
      }

      res.render('opettaja_update', {
         opettaja: opettaja
      });

   });
});


router.post('/update', (req, res) => {

   if (req.body._cancel) {
      res.redirect(`/opettajat/${req.body.key}`);
      return;
   }

   delete req.body._update;

   Opettaja.update(req.body, (key) => {
      res.redirect(`/opettajat/${key}`);
   });

});


/*
 * DELETE
 */


router.get('/:key/delete', (req, res) => {

   Opettaja.findByKey(req.params.key, (opettaja) => {

      if (!opettaja) {
         res.render('opettaja_detail');
         return;
      }
              
      res.render('opettaja_delete', {
         opettaja: opettaja
      });
   });
});


router.post('/delete', (req, res) => {

   if (req.body._cancel) {
      res.redirect('/opettajat/' + req.body.key);
      return;
   }

   Opettaja.destroy(req.body.key, () => {
      res.redirect('/opettajat');
   });

});


/*
 * SELECT
 */

router.get('/', (req, res) => {

   Opettaja.findAll((opettajat) => {

      //log(module.filename, opettajat);

      res.render('opettaja_list', {
         opettajat: opettajat
      });

   });
});


router.get('/:key', (req, res) => {

   Opettaja.findByKey(req.params.key, (opettaja) => {

      res.render('opettaja_detail', {
         opettaja: opettaja
      });
   });

});







