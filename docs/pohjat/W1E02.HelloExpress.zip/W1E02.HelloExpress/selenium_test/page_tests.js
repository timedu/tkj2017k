

/*
 * Use Selenium Web Driver
 */

var test = require('selenium-webdriver/testing');
var webdriver = require('selenium-webdriver');
var until = webdriver.until;

/*
 * Use PhantomJS as Browser
 */

var phantomjs_exe = require('phantomjs-prebuilt').path;

var customPhantom = webdriver.Capabilities.phantomjs();
customPhantom.set("phantomjs.binary.path", phantomjs_exe);

var browser = new webdriver.Builder()
        .withCapabilities(customPhantom).build();

/*
 * Perform tests
 */

const Timeout = 500;

const ServerAddress = 'http://127.0.0.1:3000';

const URL1 = `/${Math.random()}`;
const URL2 = `/${Math.random()}`;

const ExpectedContent = (count, url) => {
    return `Hello ${count} from Express (${url})`;
};

const ErrorMessage = (expectedContent) => {
    return `Sivulta ei löydy tekstiä "${expectedContent}".`;
};


test.describe('Sivutestit:', function () {

    // test.before(function () {});

    test.it('esittää ensimmäisellä pyynnöllä odotetun sisällön', function () {

        const URL = URL1;
        const ExpectedCount = 1;

        var content = ExpectedContent(1, URL1);

        browser.get(`${ServerAddress}${URL}`);
        browser.wait(function () {
            return browser.getPageSource().then(function (source) {
                return source.includes(content);
            });
        }, Timeout, ErrorMessage(content));

    });

    test.it('kasvattaa laskuria seuraavilla pyynnöillä', function () {

        const URL = URL1;

        [2, 3].forEach((count) => {

            var ExpectedCount = count;
            var content = ExpectedContent(ExpectedCount, URL);

            browser.get(`${ServerAddress}${URL}`);
            browser.wait(function () {
                return browser.getPageSource().then(function (source) {
                    return source.includes(content);
                });
            }, Timeout, ErrorMessage(content));

        });
    });

    test.it('siirtää laskurin alkuun pyynnöllä toiseen polkuun', function () {

        const URL = URL2;
        const ExpectedCount = 1;

        var content = ExpectedContent(ExpectedCount, URL);

        browser.get(`${ServerAddress}${URL}`);
        browser.wait(function () {
            return browser.getPageSource().then(function (source) {
                return source.includes(content);
            });
        }, Timeout, ErrorMessage(content));

    });

    test.it('jatkaa ensimmäisen polun laskurin askeltamista', function () {

        const URL = URL1;
        const ExpectedCount = 4;

        var content = ExpectedContent(ExpectedCount, URL);

        browser.get(`${ServerAddress}${URL}`);
        browser.wait(function () {
            return browser.getPageSource().then(function (source) {
                return source.includes(content);
            });
        }, Timeout, ErrorMessage(content));

    });

    // test.after(function () {});

});

