
// TKJ2017k, Tehtävä 1.2

// Nimi: 
// OppNro: 

var requests = [];

module.exports = function (url) {
    
    return 9;
};
