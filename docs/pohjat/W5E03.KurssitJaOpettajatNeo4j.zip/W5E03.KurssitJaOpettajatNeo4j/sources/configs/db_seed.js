
/* global __dirname, Promise */

const log = (msg) => {
   require('./utils').log(module.filename, msg);
};
log();


const csv = require('csvtojson');
const db = require('./db_connection');
const DataDir = `${__dirname}/db_seed`;


module.exports = () => {

   ensureGraphIsEmpty().then(() => {

      Promise.all([

         readCSV('opettajat'),
         readCSV('kurssit')

      ]).then(dataArr => {

         const opettajaArr = dataArr[0];
         const kurssiArr = dataArr[1];

         const opettaja_map = {}; // avaimena tunnus

         const session = db.session();
         const tx = session.beginTransaction();

         opettajaArr.forEach((opettaja) => {

            tx.run("CREATE (:Opettaja {sukunimi: {sn}, etunimi: {en}})", {
               sn: opettaja.sukunimi,
               en: opettaja.etunimi
            });

            opettaja_map[opettaja.tunnus] = opettaja;

         });

         // opettaja, jolla ei ole kursseja
         tx.run("CREATE (:Opettaja {sukunimi: {sn}, etunimi: {en}})", {
            sn: 'Simpsonius',
            en: 'Bartholomeus'
         });

         kurssiArr.forEach((kurssi) => {

            tx.run("CREATE (:Kurssi {tunnus: {t}, nimi: {n}, laajuus: {l}})", {
               t: kurssi.tunnus,
               n: kurssi.nimi,
               l: kurssi.laajuus
            });

            tx.run(" MATCH (o:Opettaja), (k:Kurssi) \
                     WHERE o.sukunimi = {os} AND k.tunnus = {kt} \
                     CREATE (o)-[:OPETTAA]->(k)", {
               kt: kurssi.tunnus,
               os: opettaja_map[kurssi.opettaja].sukunimi
            });

         });

         // kurssi, jolla ei ole opettajaa
         tx.run("CREATE (:Kurssi {tunnus: {t}, nimi: {n}, laajuus: {l}})", {
            t: 'PLA-33300',
            n: 'Johdatus ohjelmistotuotantoon',
            l: '5'
         });

         // kurssien esitietovaatimukset

         [
            {
               kurssi: 'Olio-ohjelmointi',
               esitieto: 'Ohjelmointitekniikka',
               tyyppi: 'p'
            },
            {
               kurssi: 'Tietorakenteet',
               esitieto: 'Olio-ohjelmointi',
               tyyppi: 'p'
            },
            {
               kurssi: 'Sulautetut järjestelmät',
               esitieto: 'Olio-ohjelmointi',
               tyyppi: 'p'
            },
            {
               kurssi: 'Tietokantajärjestelmät',
               esitieto: 'Olio-ohjelmointi',
               tyyppi: 's'
            },
            {
               kurssi: 'Tietokantajärjestelmät',
               esitieto: 'Tiedonhallinta ja tietokannat',
               tyyppi: 's'
            },
            {
               kurssi: 'Tietokantajärjestelmät',
               esitieto: 'Web-ohjelmointi',
               tyyppi: 's'
            },
            {
               kurssi: 'Web-ohjelmointi',
               esitieto: 'Ohjelmointitekniikka',
               tyyppi: 'p'
            },
            {
               kurssi: 'Web-ohjelmointi',
               esitieto: 'Olio-ohjelmointi',
               tyyppi: 's'
            },
            {
               kurssi: 'Web-ohjelmointi',
               esitieto: 'Tiedonhallinta ja tietokannat',
               tyyppi: 's'
            },
            {
               kurssi: 'Mobiiliohjelmointi',
               esitieto: 'Olio-ohjelmointi',
               tyyppi: 'p'
            },
            {
               kurssi: 'Web-selainohjelmointi',
               esitieto: 'Olio-ohjelmointi',
               tyyppi: 's'
            },
            {
               kurssi: 'Web-selainohjelmointi',
               esitieto: 'Web-ohjelmointi',
               tyyppi: 's'
            },
            {
               kurssi: 'Web-palvelinohjelmointi',
               esitieto: 'Olio-ohjelmointi',
               tyyppi: 'p'
            },
            {
               kurssi: 'Web-palvelinohjelmointi',
               esitieto: 'Tiedonhallinta ja tietokannat',
               tyyppi: 's'
            },
            {
               kurssi: 'Web-palvelinohjelmointi',
               esitieto: 'Web-ohjelmointi',
               tyyppi: 's'
            },
            {
               kurssi: 'Software Engineering Management',
               esitieto: 'Ohjelmointitekniikka',
               tyyppi: 's'
            },
            {
               kurssi: 'Ohjelmistotuotteen hallinta',
               esitieto: 'Ohjelmointitekniikka',
               tyyppi: 'p'
            },
            {
               kurssi: 'Ohjelmistotuotteen hallinta',
               esitieto: 'Tietojärjestelmän mallintaminen',
               tyyppi: 's'
            },
            {
               kurssi: 'Ohjelmistotuotteen hallinta',
               esitieto: 'Software Engineering Management',
               tyyppi: 's'
            },
            {
               kurssi: 'Ohjelmistoprojekti',
               esitieto: 'Ohjelmointitekniikka',
               tyyppi: 'p'
            },
            {
               kurssi: 'Ohjelmistoprojekti',
               esitieto: 'Olio-ohjelmointi',
               tyyppi: 's'
            },
            {
               kurssi: 'Ohjelmistoprojekti',
               esitieto: 'Tiedonhallinta ja tietokannat',
               tyyppi: 'p'
            },
            {
               kurssi: 'Ohjelmistoprojekti',
               esitieto: 'Web-ohjelmointi',
               tyyppi: 's'
            },
            {
               kurssi: 'Ohjelmistoprojekti',
               esitieto: 'Käyttäjäkeskeinen suunnittelu',
               tyyppi: 's'
            },
            {
               kurssi: 'Ohjelmistoprojekti',
               esitieto: 'Tietojärjestelmän mallintaminen',
               tyyppi: 's'
            },
            {
               kurssi: 'Ohjelmistoprojekti',
               esitieto: 'Software Engineering Management',
               tyyppi: 's'
            },
            {
               kurssi: 'Ohjelmistoprojekti',
               esitieto: 'Ohjelmistotuotteen hallinta',
               tyyppi: 's'
            }
         ].forEach((vaade) => {

            tx.run(" MATCH (k1:Kurssi {nimi: {kn1} } ),  \
                           (k2:Kurssi {nimi: {kn2} } )   \
                     CREATE (k1)-[:ON_ESITIETO {tyyppi: {ps} }]->(k2)", {
               kn1: vaade.esitieto,
               kn2: vaade.kurssi,
               ps: vaade.tyyppi
            });
         });

         tx.commit().subscribe({
            onCompleted: function () {
               session.close();
               log('nodes and arcs created');
            },
            onError: function (error) {
               log(error);
            }
         });

      }, reason => {
         log(reason);
      });
   }, reason => {
      log(reason);
   });
};



/**
 * Tarkistaa, sisältääkö tietokanta kolmikkoja
 * @returns {Promise}
 */
function ensureGraphIsEmpty() {

   return new Promise((resolve, reject) => {

      const session = db.session();

      session.run("MATCH (n) RETURN n LIMIT 1").then((result) => {

         if (result.records.length) {
            reject('db already contains nodes');
         } else {
            resolve();
         }
         session.close();

      }).catch(function (error) {
         reject(error);
      });

   });
}


/**
 * Lukee csv-tiedoston sisällön 
 * @param file {String} csv-tiedoston nimi ilman polkua ja suffiksia
 * @returns {Promise}
 */
function readCSV(file) {

   return new Promise((resolve, reject) => {

      csv({delimiter: ';'}).fromFile(`${DataDir}/${file}.csv`)

              .on('end_parsed', (objArr) => {
                 resolve(objArr);
                 log(`${file} csv read`);
              })
              .on('error', (err) => {
                 reject(err);
              });
   });
}

