
require('./utils').log(module.filename);

const neo4j = require('neo4j-driver').v1;


// tunnisteet moodlesta

const URL = '';
const USER = '';
const PWD = '';

const driver = neo4j.driver(URL, neo4j.auth.basic(USER, PWD));

module.exports = driver;

