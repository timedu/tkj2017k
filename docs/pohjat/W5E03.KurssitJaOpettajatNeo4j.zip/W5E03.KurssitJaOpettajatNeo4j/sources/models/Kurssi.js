
/* global Promise */

const utils = require('../configs/utils');

const log = utils.log;
const arrify = utils.arrify;

log(module.filename);


// TKJ2017k, Tehtävä 5.3

// Nimi: 
// OppNro: 


const db = require('../configs/db_connection');

const Kurssi = {};
module.exports = Kurssi;


Kurssi.findAll = (callback) => {

    callback([]);

};


Kurssi.findByKey = (kurssi_key, callback) => {

    callback({});

};

