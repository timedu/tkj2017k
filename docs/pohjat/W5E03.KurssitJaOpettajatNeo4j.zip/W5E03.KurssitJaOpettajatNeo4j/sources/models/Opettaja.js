
const utils = require('../configs/utils');

const log = utils.log;
const arrify = utils.arrify;

log(module.filename);


// TKJ2017k, Tehtävä 5.3

// Nimi: 
// OppNro: 


const db = require('../configs/db_connection');

const Opettaja = {};
module.exports = Opettaja;


Opettaja.findAll = (callback) => {

   const session = db.session();

   session.run("MATCH (o:Opettaja) RETURN o ORDER BY o.sukunimi").then((result) => {

//      const opettajat = [];
//
//      result.records.forEach((record) => {
//         var opettaja = Object.assign({}, record.get(0).properties);
//         opettaja.key = record.get(0).identity.toString();
//         opettajat.push(opettaja);
//      });

      const opettajat = arrify(result.records);

      callback(opettajat);

      session.close();

   }).catch((error) => {

      console.log(error);
      callback([]);

   });

};


Opettaja.findByKey = (opettaja_key, callback) => {

   const session = db.session();

   session.run("  MATCH (o:Opettaja)                           \
                  WHERE ID(o) = toInt({id})                    \
                  OPTIONAL MATCH (o)-[:OPETTAA]-> (k:Kurssi)   \
                  RETURN o, k                                  \
                  ORDER BY k.nimi", {
      id: opettaja_key

   }).then((result) => {

//      const opettaja = Object.assign({}, result.records[0].get(0).properties);
//      opettaja.key = result.records[0].get(0).identity.toString();
//
//      const kurssit = [];
//
//      if (result.records[0].get(1)) {
//         result.records.forEach((record) => {
//            var kurssi = Object.assign({}, record.get(1).properties);
//            kurssi.key = record.get(1).identity.toString();
//            kurssit.push(kurssi);
//         });
//      }
//
//      opettaja.kurssit = kurssit;

      const opettaja = arrify(result.records)[0];
      opettaja.kurssit = arrify(result.records, 1);

      callback(opettaja);
      session.close();

   }).catch((error) => {

      console.log(error);
      callback({});

   });

};

