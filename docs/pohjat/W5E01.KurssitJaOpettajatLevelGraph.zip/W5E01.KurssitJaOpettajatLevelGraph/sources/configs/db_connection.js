
require('./utils').log(module.filename);

const Level = require('level');
const LevelGraph = require("levelgraph");

const DB_FILE = './database/koulu.level';

module.exports = {
  graph: LevelGraph(Level(DB_FILE))
};

