
/* global __dirname, Promise */

const log = (msg) => {
   require('./utils').log(module.filename, msg);
};
log();


const csv = require('csvtojson');
const cuid = require('cuid');
const db = require('./db_connection');
const DataDir = `${__dirname}/db_seed`;


module.exports = () => {

   ensureGraphIsEmpty().then(() => {

      Promise.all([

         readCSV('opettajat'),
         readCSV('kurssit')

      ]).then(dataArr => {

         const opettajaArr = dataArr[0];
         const kurssiArr = dataArr[1];
         // log(opettajaArr);
         // log(kurssiArr);

         const triples = [];

         const opettaja_map = {}; // avaimena tunnus

         opettajaArr.forEach((opettaja) => {

            opettaja.key = cuid();
            opettaja_map[opettaja.tunnus] = opettaja;

            triples.push({
               subject: opettaja.key,
               predicate: 'on_opettaja',
               object: {
                  sukunimi: opettaja.sukunimi,
                  etunimi: opettaja.etunimi
               }
            });
         });

         kurssiArr.forEach((kurssi) => {

            const kurssi_key = cuid();

            triples.push({
               subject: opettaja_map[kurssi.opettaja].key,
               predicate: "opettaa",
               object: kurssi_key
            });

            triples.push({
               subject: kurssi_key,
               predicate: 'on_kurssi',
               object: {
                  tunnus: kurssi.tunnus,
                  nimi: kurssi.nimi,
                  laajuus: kurssi.laajuus
               }
            });
         });

         db.graph.put(triples, (err) => {
            err || log_database();
         });

      }, reason => {
         log(reason);
      });
   }, reason => {
      log(reason);
   });
};

/**
 * Tulostaa tietokannan koko sisällön
 * @returns {undefined}
 */

function log_database() {

   log('OPETTAJAT');

   db.graph.get({predicate: 'on_opettaja'}, (err, list) => {
      console.log(list);

      log('KURSSIT');

      db.graph.get({predicate: 'on_kurssi'}, (err, list) => {
         console.log(list);

         log('OPETTAA');

         db.graph.get({predicate: 'opettaa'}, (err, list) => {
            console.log(list);
         });
      });
   });

}


/**
 * Tarkistaa, sisältääkö tietokanta kolmikkoja
 * @returns {Promise}
 */
function ensureGraphIsEmpty() {

   return new Promise((resolve, reject) => {
      db.graph.get({limit: 1}, (err, list) => {
         if (list.length) {
            reject('db.graph already contains triples');
         } else {
            resolve();
         }
      });
   });
}


/**
 * Lukee csv-tiedoston sisällön 
 * @param file {String} csv-tiedoston nimi ilman polkua ja suffiksia
 * @returns {Promise}
 */
function readCSV(file) {

   return new Promise((resolve, reject) => {

      csv({delimiter: ';'}).fromFile(`${DataDir}/${file}.csv`)

              .on('end_parsed', (objArr) => {
                 resolve(objArr);
                 log(`${file} csv read`);
              })
              .on('error', (err) => {
                 reject(err);
              });
   });
}

