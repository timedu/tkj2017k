
const log = require('../configs/log');
log(module.filename);


// TKJ2017k, Tehtävä 3.1

// Nimi: 
// OppNro: 


const db = require('../configs/db_connection');


const Opettaja = {};

module.exports = Opettaja;


Opettaja.findAll = (callback) => {

   callback([
      {
         tunnus: 'ap',
         sukunimi: 'Ahtola',
         etunimi: 'Pertti'
      }, {
         tunnus: 'jv',
         sukunimi: 'Jukola',
         etunimi: 'Leevi'
      }]);

};


Opettaja.findByKey = (key, callback) => {

   callback({
      tunnus: 'ps',
      sukunimi: 'Pasanen',
      etunimi: 'Simo'
   });

};
