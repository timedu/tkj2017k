
const log = require('../configs/log');
log(module.filename);


// TKJ2017k, Tehtävä 3.1

// Nimi: 
// OppNro: 


const db = require('../configs/db_connection');

const Kurssi = {};

module.exports = Kurssi;

Kurssi.findAll = (callback) => {

   callback([
      {
         tunnus: 'PLA-32602',
         nimi: 'Tiedonhallinta ja tietokannat',
         laajuus: 4,
         opettaja: 'vk'
      }, {
         tunnus: 'PLA-32610',
         nimi: 'Tietokantajärjestelmät',
         laajuus: 4,
         opettaja: 'ks'
      }]);
   
};


Kurssi.findByKey = (key, callback) => {

   callback({
      tunnus: 'PLA-32610',
      nimi: 'Tietokantajärjestelmät',
      laajuus: 4,
      opettaja: 'ks'
   });

};


Kurssi.findAllByOpettaja = (opettajaTunnus, callback) => {

   const opettajanKurssit = [];

   db.kurssi.createValueStream({
      valueEncoding: 'json'
   }).on('data', (kurssi) => {
      if (kurssi.opettaja === opettajaTunnus) {
         opettajanKurssit.push(kurssi);
      }
   }).on('end', () => {
      callback(opettajanKurssit);
   });

};

