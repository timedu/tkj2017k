
require('../configs/log')(module.filename);

// TKJ2017k, Tehtävä 3.1

// Nimi: 
// OppNro: 


const Opettaja = require('../models/Opettaja');
const Kurssi = require('../models/Kurssi');

module.exports = router = require('express').Router();


router.get('/', (req, res) => {

   Opettaja.findAll((opettajat) => {

      res.render('opettaja_list', {
         opettajat: opettajat
      });

   });

});


router.get('/:key', (req, res) => {

   Opettaja.findByKey(req.params.key, (opettaja) => {

      Kurssi.findAllByOpettaja(opettaja.tunnus, (kurssit) => {
         
         opettaja.kurssit = kurssit;
         
         res.render('opettaja_detail', {
            opettaja: opettaja
         });

      });
   });

});

