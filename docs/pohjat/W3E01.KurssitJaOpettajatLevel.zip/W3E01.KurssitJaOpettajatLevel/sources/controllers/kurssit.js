
require('../configs/log')(module.filename);

// TKJ2017k, Tehtävä 3.1

// Nimi: 
// OppNro: 


const Kurssi = require('../models/Kurssi');
const Opettaja = require('../models/Opettaja');

module.exports = router = require('express').Router();


router.get('/', (req, res) => {

   Kurssi.findAll((kurssit) => {

      res.render('kurssi_list', {
         kurssit: kurssit
      });

   });

});


router.get('/:key', (req, res) => {

   Kurssi.findByKey(req.params.key, (kurssi) => {

      Opettaja.findByKey(kurssi.opettaja, (opettaja) => {

         kurssi.opettaja = opettaja;
         
         res.render('kurssi_detail', {
            kurssi: kurssi
         });

      });

   });

});

