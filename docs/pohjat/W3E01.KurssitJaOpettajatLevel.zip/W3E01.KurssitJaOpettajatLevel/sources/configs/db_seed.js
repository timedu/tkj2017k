
/* global __dirname */

const _log = require('./log');
const log = (msg) => {
   _log(module.filename, msg);
};
log();

const csv = require('csvtojson');

const db = require('./db_connection');

const Opettaja = db.opettaja;
const Kurssi = db.kurssi;

module.exports = () => {

   const DataDir = `${__dirname}/db_seed`;

   checkIfOpettajaHasRows();
   checkIfKurssiHasRows();


   function checkIfOpettajaHasRows() {

      var count = 0;

      db.opettaja.createKeyStream().on('data', () => {

         count++;

      }).on('end', () => {

         if (!count) {
            readOpettajatCSV();
         } else {
            log(`Opettaja already has ${count} row(s)`);
         }

      });
   }


   function readOpettajatCSV() {

      csv({delimiter: ';'}).fromFile(`${DataDir}/opettajat.csv`)
              .on('end_parsed', (objArr) => {
                 log('opettaja-data read');
                 insertOpettajat(objArr);
              })
              .on('error', (err) => {
                 log(err);
              });
   }


   function insertOpettajat(opettajatCSV) {

      const ops = [];

      opettajatCSV.forEach((opettaja) => {
         ops.push({
            key: opettaja.tunnus,
            value: opettaja
         });
      });

      db.opettaja.batch(ops, {valueEncoding: 'json'}, (err) => {
         if (err) {
            return log('Opettaja : unable to create rows', err);
         }
         log('Opettaja : rows created');
      });

   }


    function checkIfKurssiHasRows() {

      var count = 0;

      Kurssi.createKeyStream().on('data', () => {

         count++;

      }).on('end', () => {

         if (!count) {
            readKurssitCSV();
         } else {
            log(`Kurssi already has ${count} row(s)`);
         }

      });

    }



    function readKurssitCSV() {

        csv({delimiter: ';'}).fromFile(`${DataDir}/kurssit.csv`)
                .on('end_parsed', (objArr) => {
                    log('kurssi-data read');
                    insertKurssit(objArr);
                })
                .on('error', (err) => {
                    log(err);
                });
    }



    function insertKurssit(kurssitCSV) {

      const ops = [];

      kurssitCSV.forEach((kurssi) => {
         ops.push({
            key: kurssi.tunnus,
            value: kurssi
         });
      });

      Kurssi.batch(ops, {valueEncoding: 'json'}, (err) => {
         if (err) {
            return log('Kurssi : unable to create rows', err);
         }
         log('Kurssi : rows created');
      });

        
    }
};

