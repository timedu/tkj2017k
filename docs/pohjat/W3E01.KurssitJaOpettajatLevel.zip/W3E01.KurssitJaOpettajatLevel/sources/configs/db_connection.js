
require('./log')(module.filename);

const Level = require('level');

const KurssiDatabase = './database/kurssi.level';
const OpettajaDatabase = './database/opettaja.level';

module.exports = {
   kurssi: Level(KurssiDatabase),
   opettaja: Level(OpettajaDatabase),
};

