
/* global Promise */

const log = (msg) => {
   require('./utils').log(module.filename, msg);
};
log();

const db = require('./db_connection');


/*
 * -------------------------------------------------------------------
 * INSERT: Opettajat
 */

const InsertOpettajat = "\
INSERT INTO Opettaja(tunnus, sukunimi, etunimi) \
VALUES \
('vk', 'Veto', 'Karri'),         \
('jv', 'Jukola', 'Leevi'),       \
('rn', 'Rämeenperä', 'Niilo'),   \
('ap', 'Ahtola', 'Pertti'),      \
('ms', 'Mikama', 'Santtu'),      \
('ks', 'Käkilä', 'Simo')         \
";


/*
 * -------------------------------------------------------------------
 * INSERT: Kurssit
 */

const InsertKurssit = "\
INSERT INTO Kurssi(tunnus, nimi, laajuus, o_tunnus) \
VALUES \
('PLA-31100','Ohjelmointitekniikka','6','ms'),           \
('PLA-32100','Olio-ohjelmointi','6','ms'),               \
('PLA-32200','Tietorakenteet','6','rn'),                 \
('PLA-32310','Sulautetut järjestelmät','6','ms'),        \
('PLA-32602','Tiedonhallinta ja tietokannat','4','vk'),  \
('PLA-32610','Tietokantajärjestelmät','4','ks'),         \
('PLA-32811','Web-ohjelmointi','4','ks'),                \
('PLA-32820','Mobiiliohjelmointi','5','ms'),             \
('PLA-32831','Web-selainohjelmointi','4','ks'),          \
('PLA-32841','Web-palvelinohjelmointi','4','ks'),        \
('PLA-33110','Käyttäjäkeskeinen suunnittelu','4','ap'),  \
('PLA-33120','Tietojärjestelmän mallintaminen','5','jv'),\
('PLA-33416','Software Engineering Management','5','vk'),\
('PLA-33450','Ohjelmistotuotteen hallinta','4','vk'),    \
('PLA-33600','Ohjelmistoprojekti','5-9','vk')            \
";


/*
 * -------------------------------------------------------------------
 * UPDATE: Kurssien opettajat
 */

const UpdateKurssienOpettajat = "\
UPDATE Kurssi           \
SET opettaja = (        \
   SELECT FROM Opettaja \
   WHERE tunnus = $parent.$current.o_tunnus \
)";


/*
 * -------------------------------------------------------------------
 * UPDATE: Opettajien kurssit
 */

const UpdateOpettajienKurssit = "\
UPDATE Opettaja         \
SET kurssit = (         \
   SELECT FROM Kurssi   \
   WHERE o_tunnus = $parent.$current.tunnus \
   ORDER BY nimi \
)";


/*
 * -------------------------------------------------------------------
 * module.exports : initialize database
 */

module.exports = () => {

   // --
   // jos tietokantaa ei tarvitse luoda uudelleen, seuraavan
   // return-lauseen voi aktivoida
   // 
   //return; 

   Promise.all([

      createOpettajaClass(),
      createKurssiClass()

   ]).then(() => {

      Promise.all([

         db.query('TRUNCATE CLASS Opettaja'),
         db.query('TRUNCATE CLASS Kurssi')

      ]).then(() => {
         log('classes truncated');

         Promise.all([

            db.query(InsertOpettajat),
            db.query(InsertKurssit)

         ]).then(() => {
            log('records inserted');

            Promise.all([

               db.query(UpdateKurssienOpettajat),
               db.query(UpdateOpettajienKurssit)

            ]).then(() => {
               log('links updated');

            }).catch(error => {
               log(error);
            }); // update links

         }).catch(error => {
            log(error);
         }); // insert records

      }).catch(error => {
         log(error);
      }); // truncate records

   }).catch(error => {
      log(error);
   }); // create classes

}; // module.exports


/**
 * 
 * @returns {Promise}
 */

function createKurssiClass() {

   return new Promise((resolve) => {

      db.class.create('Kurssi').then((C) => {

         log('class created: ' + C.name);

         C.property.create({
            name: 'opettaja',
            type: 'Link'
         }).then(property => {

            log("property created: " + property.name);
            resolve();

         }).catch(error => {

            log(error.message);
            resolve();
         });

      }).catch(error => {

         log(error.message);
         resolve();

      });

   });
}

/**
 * 
 * @returns {Promise}
 */
function createOpettajaClass() {

   return new Promise((resolve) => {

      db.class.create('Opettaja').then((C) => {

         log('class created: ' + C.name);

         C.property.create({
            name: 'kurssit',
            type: 'Linklist'
         }).then(property => {

            log("property created: " + property.name);
            resolve();

         }).catch(error => {

            log(error.message);
            resolve();
         });

      }).catch(error => {

         log(error.message);
         resolve();

      });

   });
}

