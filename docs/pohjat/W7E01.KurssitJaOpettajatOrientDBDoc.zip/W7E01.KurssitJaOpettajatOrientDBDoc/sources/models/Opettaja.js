
const log = (msg) => {
   require('../configs/utils').log(module.filename, msg);
};
log();


// TKJ2017k, Tehtävä 7.1

// Nimi: 
// OppNro: 


const db = require('../configs/db_connection');

const Opettaja = {};
module.exports = Opettaja;


const FindAllOpettajat = '\
SELECT @RID.asString().substring(1) AS key, sukunimi, etunimi \
FROM Opettaja \
ORDER BY sukunimi';

Opettaja.findAll = (callback) => {

   callback([]);

};


// substring 'purisi' vain ensimmäisen kurssin ridiin

const FindOpettajaByKey = '\
SELECT \
   @RID.substring(1) AS key, \
   sukunimi, \
   etunimi, \
   kurssit.@RID AS kurssi_rid, \
   kurssit.nimi AS kurssi_nimi \
FROM Opettaja \
WHERE @RID = :rid';

Opettaja.findByKey = (opettaja_key, callback) => {

   callback({});

};


/*
 * INSERT
 */

Opettaja.create = (opettaja, callback) => {

   callback('');

};


/*
 * UPDATE
 */

Opettaja.update = (opettaja, callback) => {

   callback('');

};

/*
 * DELETE
 */

Opettaja.destroy = (key, callback) => {

   callback();

};

