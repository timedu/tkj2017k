
const log = (msg) => {
   require('../configs/utils').log(module.filename, msg);
};
log();


// TKJ2017k, Tehtävä 7.1

// Nimi: 
// OppNro: 


const db = require('../configs/db_connection');

const Kurssi = {};
module.exports = Kurssi;


const FindAllKurssit = '\
SELECT @RID.substring(1) AS key, nimi \
FROM Kurssi \
ORDER BY nimi';


Kurssi.findAll = (callback) => {

   // callback([]);

};


//
// Database API:n query-metodiin perustuvan ratkaisun
// kysely:
// 

const FindKurssiByKey = '\
SELECT \
  @RID.substring(1) AS key, \
  tunnus,   \
  nimi,     \
  laajuus,  \
  opettaja.sukunimi AS opettaja_sukunimi,    \
  opettaja.etunimi  AS opettaja_etunimi,     \
  opettaja.@RID.substring(1) AS opettaja_key \
FROM Kurssi \
WHERE @RID = :rid';


Kurssi.findByKey = (kurssi_key, callback) => {

   // callback({});

};

