
const log = msg => {
   require('./utils').log(module.filename, msg);
};

const cassandra = require('cassandra-driver');

const IP = '192.168.1.47';
const PORT = '9042';
const USER = 'cassandra';
const PWD = 'bitnami';

const client = new cassandra.Client({
   contactPoints: [`${IP}:${PORT}`],
   authProvider: new cassandra.auth.PlainTextAuthProvider(USER, PWD)
});

client.connect(function (err) {
   if (err)
      return log(err);
   log('logged to cassandra');
});

module.exports = client;

