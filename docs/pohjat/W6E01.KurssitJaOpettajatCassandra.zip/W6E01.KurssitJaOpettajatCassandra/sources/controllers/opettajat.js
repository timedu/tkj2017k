
const log = require('../configs/log');
log(module.filename);

// TKJ2017k, Tehtävä 6.1

// Nimi: 
// OppNro: 


const Opettaja = require('../models/Opettaja');

module.exports = router = require('express').Router();


router.get('/', (req, res) => {

   Opettaja.findAll((opettajat) => {

      //log(module.filename, opettajat);

      res.render('opettaja_list', {
         opettajat: opettajat
      });

   });
});


router.get('/:key', (req, res) => {

   Opettaja.findByKey(req.params.key, (opettaja) => {

      res.render('opettaja_detail', {
         opettaja: opettaja
      });
   });

});







