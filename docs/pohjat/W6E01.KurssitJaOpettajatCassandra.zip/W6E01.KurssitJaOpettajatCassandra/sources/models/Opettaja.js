
const log = (msg) => {
   require('../configs/utils').log(module.filename, msg);
};
log();


// TKJ2017k, Tehtävä 6.1

// Nimi: 
// OppNro: 


const db = require('../configs/db_connection');

const Opettaja = {};
module.exports = Opettaja;


Opettaja.findAll = (callback) => {

   callback([]);

};


Opettaja.findByKey = (opettaja_key, callback) => {

   callback({});

};

