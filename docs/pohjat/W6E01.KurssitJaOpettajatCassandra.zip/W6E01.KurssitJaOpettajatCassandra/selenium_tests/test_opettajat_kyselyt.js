
var assert = require('assert');
var webdriver = require('selenium-webdriver');
var test = require('selenium-webdriver/testing');
var By = webdriver.By;

/*
 * Use PhantomJS as Browser
 */

var phantomjs_exe = require('phantomjs-prebuilt').path;
var customPhantom = webdriver.Capabilities.phantomjs();
customPhantom.set("phantomjs.binary.path", phantomjs_exe);
var browser = new webdriver.Builder()
        .withCapabilities(customPhantom).build();
/*
 * Execute Tests
 */

const ServerAddress = 'http://127.0.0.1:3000';


test.describe('opettajat_kyselyt:', function () {

   var tests_succeeded_so_far = false;

   // -------------------------------------------------------------------
   test.it('opettajat-sivulla on odotettu sisältö', () => {
      // ----------------------------------------------------------------

      /*
       * Siirrytään Opettajat -sivulle
       */

      browser.get(`${ServerAddress}/opettajat`).then(() => {

         /*
          * Sivulla on otsikko "Opettajat"
          */

         const ExpectedH2Content = 'Opettajat';

         browser.findElement(By.css('h2')).getText().then((elementText) => {
            assert.ok(elementText.includes(ExpectedH2Content),
                    `h2-elementin sisältö: "${elementText}"; odotettu sisältö: "${ExpectedH2Content}"`);
         });

         /*
          * Sivulla on 6 opettajaa
          */

         const ExpectedLength = 6;

         browser.findElements(By.css('li a')).then((opettajaLinks) => {

            assert.equal(opettajaLinks.length, ExpectedLength,
                    `"li a"-elementien lukumäärä: "${opettajaLinks.length}"; odotettu määrä: "${ExpectedLength}"`);

         });

         /*
          * Sivulla on opettajat "Ahtola", "Jukola" ja "Mikama" 
          */

         const ExpectedA0Content = 'Ahtola';
         const ExpectedA1Content = 'Jukola';
         const ExpectedA3Content = 'Mikama';

         browser.findElement(By.css('body')).getText().then((bodyText) => {

            assert.ok(bodyText.includes(ExpectedA0Content),
                    'Sivulta ei löydy opettajaa ' + ExpectedA0Content);

            assert.ok(bodyText.includes(ExpectedA1Content),
                    'Sivulta ei löydy opettajaa ' + ExpectedA1Content);

            assert.ok(bodyText.includes(ExpectedA3Content),
                    'Sivulta ei löydy opettajaa ' + ExpectedA3Content);

         });

         /*
          * Opettajat ovat aakkosjärjestyksessä
          */

         browser.findElements(By.css('li a')).then((elements) => {

            elements[0].getText().then((elementText) => {
               assert.ok(elementText.includes(ExpectedA0Content),
                       `1. opettaja: "${elementText}"; pitäisi olla: "${ExpectedA0Content}"`);
            });

            elements[1].getText().then((elementText) => {
               assert.ok(elementText.includes(ExpectedA1Content),
                       `2. opettaja: "${elementText}"; pitäisi olla: "${ExpectedA1Content}"`);
            });

            elements[3].getText().then((elementText) => {
               assert.ok(elementText.includes(ExpectedA3Content),
                       `4. opettaja: "${elementText}"; pitäisi olla: "${ExpectedA3Content}"`);
            });

            tests_succeeded_so_far = true;

         });

      });

   });// test.it


   // seuraava testi tallettaa tämän myöhempää käyttöä varten
   var mikamaCuid = null; // opettajan (Mikama) cuid


   // -------------------------------------------------------------------
   test.it('opettajat-sivun linkin klikkaus vie opettaja-sivulle', () => {
      // ----------------------------------------------------------------

      assert.ok(tests_succeeded_so_far,
              'Testausta jatketaan vain, jos edelliset testit onnistuvat');
      tests_succeeded_so_far = false;

      browser.get(`${ServerAddress}/opettajat`).then(() => {

         /*
          * Sivulta löyttyy Opettajat-sivulle osoittava linkki (Mikama)
          */

         browser.findElements(By.linkText('Mikama, Santtu')).then(mikamaLinks => {

            assert.equal(mikamaLinks.length, 1);

            /*
             * Poimitaan linkistä talteen Mikaman cuid 
             */

            mikamaLinks[0].getAttribute('href').then((hrefValue) => {
               const match = hrefValue.match(/\/opettajat\/(.+)/);
               assert.ok(match);
               assert.equal(match.length, 2);
               mikamaCuid = match[1];
            });

            mikamaLinks[0].click().then(() => {

               const ExpectedH2Content = 'Opettaja';
               const ExpectedInstructor = 'Mikama';

               browser.findElement(By.css('h2')).getText().then((elementText) => {
                  assert.equal(elementText, ExpectedH2Content,
                          `sivun otsikon (h2-elementti) sisältö: "${elementText}"; odotettu sisältö: "${ExpectedH2Content}"`);
               });

               browser.findElement(By.css('body')).getText().then((elementText) => {
                  assert.ok(elementText.includes(ExpectedInstructor),
                          `sivulta pitäisi (sisältö: "${elementText}") pitäisi löytyä opettaja: "${ExpectedInstructor}"`);
                  // ei välttämättä mutta melkein ...          
                  tests_succeeded_so_far = true;
               });
            });
         });
      });

   });// test.it


   // -------------------------------------------------------------------
   test.it('opettaja-sivulla on odotettu sisältö', () => {
      // ----------------------------------------------------------------

      assert.ok(tests_succeeded_so_far,
              'Testausta jatketaan vain, jos edelliset testit onnistuvat');
      tests_succeeded_so_far = false;

      const ExpectedFirstname = 'Santtu';
      const ExpectedLastname = 'Mikama';

      /*
       * Sivulla on opettajan nimi
       */

      browser.get(`${ServerAddress}/opettajat/${mikamaCuid}`).then(() => {

         browser.findElement(By.css('body')).getText().then((elementText) => {

            assert.ok(elementText.includes(ExpectedFirstname),
                    `sivulta pitäisi (sisältö: "${elementText}") pitäisi löytyä teksti: "${ExpectedFirstname}"`);

            assert.ok(elementText.includes(ExpectedLastname),
                    `sivulta pitäisi (sisältö: "${elementText}") pitäisi löytyä teksti: "${ExpectedLastname}"`);

         });

         /*
          * Sivulla on oikea määrä (4) kursseja
          */

         const ExpectedCoursesLength = 4;

         browser.findElements(By.css('li a')).then((kurssiLinks) => {

            assert.equal(kurssiLinks.length, ExpectedCoursesLength,
                    `"opettajan kurssien lukumäärä: "${kurssiLinks.length}"; odotettu määrä: "${ExpectedCoursesLength}"`);

         });

         /*
          * Sivun kurssit ovat aakkosjärjestyksessä
          */

         const ExpectedA0Content = 'Mobiiliohjelmointi';
         const ExpectedA2Content = 'Olio-ohjelmointi';

         browser.findElements(By.css('li a')).then((kurssiLinks) => {

            kurssiLinks[0].getText().then((elementText) => {
               assert.ok(elementText.includes(ExpectedA0Content),
                       `1. kurssi: "${elementText}"; pitäisi olla: "${ExpectedA0Content}"`);
            });

            kurssiLinks[2].getText().then((elementText) => {
               assert.ok(elementText.includes(ExpectedA2Content),
                       `3. kurssi: "${elementText}"; pitäisi olla: "${ExpectedA2Content}"`);
            });

            // ei välttämättä mutta melkein ...          
            tests_succeeded_so_far = true;

         });

      });

   });// test.it


   // -------------------------------------------------------------------
   test.it('opettaja-sivun linkin klikkaus oikealle vie kurssi-sivulle', () => {
      // ----------------------------------------------------------------

      assert.ok(tests_succeeded_so_far,
              'Testausta jatketaan vain, jos edelliset testit onnistuvat');


      browser.get(`${ServerAddress}/opettajat/${mikamaCuid}`).then(() => {

         browser.findElement(By.linkText('Mobiiliohjelmointi')).click().then(() => {

            const ExpectedH2Content = 'Kurssi';

            browser.findElement(By.css('h2')).getText().then((elementText) => {
               assert.equal(elementText, ExpectedH2Content,
                       `sivun otsikon (h2-elementti) sisältö: "${elementText}"; pitäisi olla: "${ExpectedH2Content}"`);
            });

            const ExpectedCoursename = 'Mobiiliohjelmointi';

            browser.findElement(By.css('body')).getText().then((elementText) => {

               assert.ok(elementText.includes(ExpectedCoursename),
                       `sivulta pitäisi (sisältö: "${elementText}") pitäisi löytyä kurssi: "${ExpectedCoursename}"`);
            });

         });

      });

   });// test.it

});

