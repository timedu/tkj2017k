
var assert = require('assert');
var webdriver = require('selenium-webdriver');
var test = require('selenium-webdriver/testing');
var By = webdriver.By;

/*
 * Use PhantomJS as Browser
 */

var phantomjs_exe = require('phantomjs-prebuilt').path;
var customPhantom = webdriver.Capabilities.phantomjs();
customPhantom.set("phantomjs.binary.path", phantomjs_exe);
var browser = new webdriver.Builder()
        .withCapabilities(customPhantom).build();
/*
 * Execute Tests
 */

const ServerAddress = 'http://127.0.0.1:3000';
const URL0 = `/${Math.random()}0`;
const URL1 = `/${Math.random()}1`;
const URL2 = `/${Math.random()}2`;


test.describe('Selenium-testit:', function () {

    test.it('asettaa "title"-elementiin odotetun sisällön', () => {
        getPageAndVerifyTitle("Hello MVC", URL0);
    });

    test.it('esittää ensimmäisellä pyynnöllä odotetun sisällön', () => {
        getPageAndVerifyContent(1, URL1);
    });

    test.it('esittää odotetun yhteenvedon', () => {
        getSummaryPageAndVerifyContent([`${URL0}: 1`, `${URL1}: 1`]);
    });

    test.it('kasvattaa laskuria seuraavilla pyynnöillä', () => {
        getPageAndVerifyContent(2, URL1);
        getPageAndVerifyContent(3, URL1);
    });

    test.it('siirtää laskurin alkuun pyynnöllä toiseen polkuun', () => {
        getPageAndVerifyContent(1, URL2);
    });

    test.it('jatkaa ensimmäisen polun laskurin askeltamista', () => {
        getPageAndVerifyContent(4, URL1);
    });

    test.it('esittää odotetun yhteenvedon', () => {
        getSummaryPageAndVerifyContent([
            `${URL0}: 1`,
            `${URL1}: 4`,
            `${URL2}: 1`
        ]);
    });

});


/*
 * Testien apufunktiot
 */

/**
 * 
 * @param {type} expectedTitle
 * @param {type} url
 * @returns {undefined}
 */
const getPageAndVerifyTitle = (expectedTitle, url) => {

    browser.get(`${ServerAddress}${url}`).then(() => {
        browser.getTitle().then(function (title) {
            assert.ok(title.includes(expectedTitle),
                    `"title"-elementin sisältönä on "${title}"`);
        });
    });
};

/**
 * 
 * @param {type} count
 * @param {type} url
 * @returns {undefined}
 */
const getPageAndVerifyContent = (count, url) => {

    const ExpectedContent = `Hello ${count} from MVC (${url})`;

    browser.get(`${ServerAddress}${url}`).then(() => {
        browser.findElement(By.css('p')).getText().then((elementText) => {
            assert.ok(elementText.includes(ExpectedContent),
                    `elementin sisältö: "${elementText}"; odotettu sisältö: "${ExpectedContent}"`);
        });
    });
};

/**
 * 
 * @param {type} expectedTexts
 * @returns {undefined}
 */
const getSummaryPageAndVerifyContent = (expectedTexts) => {

    var expectedHeading = 'Request Summary';
    var expectedPathCount = expectedTexts.length;

    browser.get(ServerAddress).then(() => {

        // otsikko
        browser.findElement(By.css('p')).getText().then((elementText) => {
            assert.ok(elementText.includes(expectedHeading),
                    `otsikon sisältö: "${elementText}"; odotettu sisältö: "${expectedHeading}"`);
        });

        // pyynnöt
        browser.findElement(By.css('div')).then((div) => {

            div.findElements(By.css('span')).then((spans) => {
                assert.equal(spans.length, expectedPathCount,
                        `polkujen lkm: "${spans.length}"; odotettu lkm: "${expectedPathCount}"`);
            });

            div.getText().then((divText) => {
                expectedTexts.forEach((expectedText) => {
                    assert.ok(divText.includes(expectedText));
                });
            });
        });

    });
};
