

// TKJ2017k, Tehtävä 1.5

// Nimi: 
// OppNro: 

const Controllers = './controllers/requestController';
const Configs = './configs/config';

const app = require('express')();
require(Controllers)(app);
require(Configs)(app).run();

