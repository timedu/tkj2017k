
// TKJ2017k, Tehtävä 1.4

// Nimi: 
// OppNro: 

var requests = {};

module.exports = {
    addRequest: (url) => {
        requests[url] = requests[url] ? ++requests[url] : 1;
    },
    getRequests: (url) => {
        return requests[url] ? requests[url] : 0;
    },
    getRequestsAll: () => {
        return requests;
    }
};
