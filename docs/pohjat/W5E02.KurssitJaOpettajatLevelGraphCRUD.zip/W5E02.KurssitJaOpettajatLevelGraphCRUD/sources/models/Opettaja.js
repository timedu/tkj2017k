
const utils = require('../configs/utils');

const sortBy = utils.sortBy;
const normalize = utils.normalize;
const log = utils.log;

log(module.filename);


// TKJ2017k, Tehtävä 5.2

// Nimi: 
// OppNro: 

const cuid = require('cuid');
const db = require('../configs/db_connection');

const Opettaja = {};
module.exports = Opettaja;


Opettaja.findAll = (callback) => {

    callback([]);

};


Opettaja.findByKey = (opettaja_key, callback) => {

    callback({});

};


/*
 * INSERT
 */

Opettaja.create = (opettaja, callback) => {
   
    callback('joku_jota_ei_oo');

};



/*
 * UPDATE
 */

Opettaja.update = (opettaja, callback) => {

    callback(opettaja.key);

};


/*
 * DELETE
 */

Opettaja.destroy = (key, callback) => {

    callback();

};

