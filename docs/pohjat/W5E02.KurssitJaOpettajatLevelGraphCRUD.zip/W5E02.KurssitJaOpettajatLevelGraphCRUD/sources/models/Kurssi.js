
const utils = require('../configs/utils');

const sortBy = utils.sortBy;
const normalize = utils.normalize;
const log = utils.log;

log(module.filename);


// TKJ2017k, Tehtävä 5.2

// Nimi: 
// OppNro: 


const db = require('../configs/db_connection');

const Kurssi = {};
module.exports = Kurssi;


Kurssi.findAll = (callback) => {

    callback([]);

};


Kurssi.findByKey = (kurssi_key, callback) => {

    callback({});

};



