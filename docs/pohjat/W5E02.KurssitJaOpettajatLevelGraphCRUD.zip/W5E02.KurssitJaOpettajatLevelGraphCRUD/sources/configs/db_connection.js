
require('./utils').log(module.filename);

const Level = require('level');
const LevelGraph = require("levelgraph");

const DB_FILE = './database/koulu.level';

const level = Level(DB_FILE);

module.exports = {
  level: level, 
  graph: LevelGraph(level)
};

