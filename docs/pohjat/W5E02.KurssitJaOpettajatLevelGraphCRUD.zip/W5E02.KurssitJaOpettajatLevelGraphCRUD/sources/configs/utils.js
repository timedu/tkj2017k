
/*
 * Apufunktioita
 */


/**
 * Tulostaa parametrit konsolille. Poistaa filename -parametrista mahdollisen
 * polun ja suffiksin
 * @param {type} filename
 * @param {type} msg
 * @returns {undefined}
 */
function log (filename, msg) {
   const ModuleName = require('path').parse(filename).name;
   console.log('***', ModuleName, msg ? ':' : '', msg || '');
};


/**
 * Lajitelelee oliotaulukon olion ominaisuuden mukaiseen aakkosjärjestykseen
 * @param {String} p ominaisuus, jonka mukaan lajittelu tapahtuu
 * @param {Array} arr lajiteltava taulukko
 * @returns {Array} lajiteltu taulukko
 */
function sortBy(p, arr) {
   return arr.sort((a, b) => {
      return a[p] <= b[p] ? -1 : 1;
   });
}


/**
 * Tekee taulukon alkioille seuraavanlaisen muunnoksen (esim.): 
 * - syöte:  { subject: 1, predicate: 2, object: { a: 3, b: 4} }
 * - tuotos: { key: 1, a: 3, b: 4 }
 * @param {Array} arr muunnettava taulukko
 * @returns {Array} muunntettu taukukko
 */
function normalize (arr) {
   return arr.map((o) => {
      const r = Object.assign({}, JSON.parse(o.object));
      r.key = o.subject;
      return r;
   });
};


module.exports = {
   sortBy: sortBy,
   normalize: normalize,
   log: log
};

