
const log = require('../configs/log');
log(module.filename);

// TKJ2017k, Tehtävä 5.2

// Nimi: 
// OppNro: 


const Kurssi = require('../models/Kurssi');


module.exports = router = require('express').Router();


router.get('/', (req, res) => {

   Kurssi.findAll(kurssit => {

      res.render('kurssi_list', {
         kurssit: kurssit
      });
   });

});


router.get('/:key', (req, res) => {

   Kurssi.findByKey(req.params.key, kurssi => {

      //log(module.filename, kurssi);

      res.render('kurssi_detail', {
         kurssi: kurssi
      });
   });

});

