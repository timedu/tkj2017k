
const log = (msg) => {
   require('../configs/utils').log(module.filename, msg);
};
log();


// TKJ2017k, Tehtävä 6.2

// Nimi: 
// OppNro: 


const db = require('../configs/db_connection');

const Kurssi = {};
module.exports = Kurssi;


Kurssi.findAll = (callback) => {

    callback([]);

};


Kurssi.findByKey = (kurssi_key, callback) => {

    callback({});

};

