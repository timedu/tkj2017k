
const log = (msg) => {
   require('../configs/utils').log(module.filename, msg);
};
log();


// TKJ2017k, Tehtävä 6.2

// Nimi: 
// OppNro: 


const Uuid = require('cassandra-driver').types.Uuid;
const db = require('../configs/db_connection');


const Opettaja = {};
module.exports = Opettaja;


/*
 * SELECT
 */

Opettaja.findAll = (callback) => {

   callback([]);

};


Opettaja.findByKey = (opettaja_key, callback) => {

   callback({});

};


/*
 * INSERT
 * - lisäys opettaja_list -tauluun
 * - lisäys opettajat -tauluun
 */

const INSERT_opettaja_list = "";
const INSERT_opettajat = "";

Opettaja.create = (opettaja, callback) => {

   callback('');

//   const Operations = [];
//
//   // ...
//
//   db.batch(Operations).then(() => {
//      callback(opettaja_key);
//   }).catch(err => {
//      log(err);
//      callback('');
//   });

};


/*
 * UPDATE
 * - muutos opettaja_list -tauluun (poisto+lisäys)
 * - muutos opettajat -tauluun
 * - muutokset kurssit -tauluun (opettajat-taulusta kurssien tunnukset)
 */

const DELETE_opettaja_list = "";
const UPDATE_opettajat = "";
const UPDATE_kurssit_opettaja = "";

Opettaja.update = (opettaja, callback) => {

   callback('');

};


/*
 * DELETE
 * - poisto opettaja_list -taulusta
 * - poisto opettajat -taulusta
 * - muutokset kurssit -tauluun (opettajat-taulusta kurssien tunnukset)
 */

const DELETE_opettajat = "";
const UPDATE_kurssit_opettaja_delete = "";

Opettaja.destroy = (key, callback) => {

   callback();

};

