
/* global __dirname */

const _log = require('./log');
const log = (msg) => {
   _log(module.filename, msg);
};
log();

const csv = require('csvtojson');

const db = require('./db_connection');

module.exports = () => {

   const DataDir = `${__dirname}/db_seed`;

   checkIfDatabaseContainsKeys();

   //
   // tarkistetaan, onko tietokannassa avaimia;
   // ei jatketa, jos avaimia löytyy
   // 

   function checkIfDatabaseContainsKeys() {

      var count = 0;

      db.createKeyStream({limit: 1}).on('data', () => {
         count++;
      }).on('end', () => {
         if (!count) {
            readOpettajatCSV();
         } else {
            log('database already contains keys');
         }
      });
   }

   //
   // luetaan opettajat csv-tiedostosta
   // 

   function readOpettajatCSV() {

      csv({delimiter: ';'}).fromFile(`${DataDir}/opettajat.csv`)
              .on('end_parsed', (objArr) => {
                 log('opettaja-data read');
                 batchOpettajat(objArr);
              })
              .on('error', (err) => {
                 log(err);
              });
   }

   //
   // talletetaan opettajat tietokantaan sekä 
   // objektiin, jota käytetään, kun opettajatiedot
   // asetetaan kurssille
   // 

   const opettajatByKeys = {};

   function batchOpettajat(opettajatCSV) {

      const ops = [];

      opettajatCSV.forEach((opettaja) => {

         opettajatByKeys[opettaja.tunnus] || (opettajatByKeys[opettaja.tunnus] = {});
         opettajatByKeys[opettaja.tunnus].opettaja = Object.assign({}, opettaja);

         ops.push({
            key: opettaja.tunnus,
            value: opettaja
         });
      });

      db.batch(ops, {valueEncoding: 'json'}, (err) => {
         if (err) {
            return log('unable to create opettaja rows', err);
         }
         log('opettaja detail rows created');
         readKurssitCSV();
      });

   }

   //
   // luetaan kurssit csv-tiedostosta
   // 

   function readKurssitCSV() {

      csv({delimiter: ';'}).fromFile(`${DataDir}/kurssit.csv`)
              .on('end_parsed', (objArr) => {
                 log('kurssi-data read');
                 bacthKurssit(objArr);
              })
              .on('error', (err) => {
                 log(err);
              });
   }

   //
   // talletetaan kurssit tietokantaan () sekä 
   // objektiin, jota käytetään, kun kurssitiedot
   // asetetaan opettajalle
   // 

   function bacthKurssit(kurssitCSV) {

      const ops = [];

      kurssitCSV.forEach((kurssi) => {

         opettajatByKeys[kurssi.opettaja].kurssit
                 || (opettajatByKeys[kurssi.opettaja].kurssit = []);
         opettajatByKeys[kurssi.opettaja].kurssit.push({
            tunnus: kurssi.tunnus,
            nimi: kurssi.nimi
         });

         kurssi.opettaja = opettajatByKeys[kurssi.opettaja].opettaja;

         ops.push({
            key: kurssi.tunnus,
            value: kurssi
         });

      });

      db.batch(ops, {valueEncoding: 'json'}, (err) => {
         if (err) {
            return log('unable to create kurssi rows', err);
         }
         log('kurssi detail rows created');
         putKurssiluetelo();
      });
   }


   function putKurssiluetelo() {

      const kurssit = [];

      db.createValueStream({
         gte: 'PLA-00000',
         lte: 'PLA-99999',
         valueEncoding: 'json'
      }).on('data', (kurssi) => {
         kurssit.push({
            tunnus: kurssi.tunnus,
            nimi: kurssi.nimi
         });
      }).on('end', () => {
         db.put('Kurssit', kurssit, {valueEncoding: 'json'}, () => {
            log('kurssi list row created');
            putOpettajaluetelo();
         });
      });

   }


   function putOpettajaluetelo() {

//      const opettajat = [];
      const opettajat = {};

      db.createValueStream({
         gte: 'aa',
         lte: 'zz',
         valueEncoding: 'json'
      }).on('data', (opettaja) => {
//         opettajat.push(data);
         opettajat[opettaja.tunnus] = opettaja;
      }).on('end', () => {
         db.put('Opettajat', opettajat, {valueEncoding: 'json'}, () => {
            log('opettaja list row created');
            patchOpettajanKurssit();
         });
      });

   }


   function patchOpettajanKurssit() {

      const ops = [];

      for (var key in opettajatByKeys) {

         var opettaja = opettajatByKeys[key].opettaja;
         opettaja.kurssit = opettajatByKeys[key].kurssit;

         ops.push({
            key: key,
            value: opettaja
         });

      }

      db.batch(ops, {valueEncoding: 'json'}, (err) => {
         if (err) {
            return log('unable to update opettaja rows', err);
         }
         log('opettaja rows updated');
         dumpDatabase();
      });

   }

   function dumpDatabase() {

      db.createReadStream().on('data', function (data) {
         console.log(data.key, '=', data.value);
      }).on('error', function (err) {
         console.log('Oh my!', err);
      });

   }

};

