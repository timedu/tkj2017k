
require('./log')(module.filename);

const Level = require('level');

const Database = './database/koulu.level';

module.exports = Level(Database);

