
log = require('../configs/log');
log(module.filename);


const db = require('../configs/db_connection');

const Opettaja = {};
module.exports = Opettaja;


/*
 * SELECT
 */


Opettaja.findAll = (callback) => {

   callback([]);

};


Opettaja.findByKey = (key, callback) => {

   callback({});

};


/*
 * INSERT
 */

Opettaja.create = (opettaja, callback) => {

   callback({});

//   opettaja.tunnus = 'zy' + Math.round((1000000 * Math.random()));
   
};


/*
 * UPDATE
 */

Opettaja.update = (newVal, callback) => {

   const ops = []; // nipussa suoritettavat tietokantaoperaatiot

   Opettaja.findAll((opettajat) => {

      opettajat[newVal.tunnus] = Object.assign({}, newVal);

      ops.push({
         key: 'Opettajat',
         value: opettajat
      });

      Opettaja.findByKey(newVal.tunnus, (opettaja) => {

         ops.push({
            key: opettaja.tunnus,
            value: Object.assign(opettaja, newVal)
         });

         db.createValueStream({

            gte: 'PLA-00000',
            lte: 'PLA-99999',
            valueEncoding: 'json'

         }).on('data', (kurssi) => {

            if (kurssi.opettaja.tunnus === newVal.tunnus) {
               kurssi.opettaja = Object.assign(kurssi.opettaja, opettaja);
            }

            ops.push({
               key: kurssi.tunnus,
               value: kurssi
            });

         }).on('end', () => {

            db.batch(ops, {valueEncoding: 'json'}, () => {
               callback && callback(opettaja);
            });

         });

      });

   });

};



/*
 * DELETE
 */


Opettaja.destroy = (delKey, callback) => {

   callback();

};
