
require('../configs/log')(module.filename);


const db = require('../configs/db_connection');

const Kurssi = {};
module.exports = Kurssi;


Kurssi.findAll = (callback) => {

   db.get('Kurssit', {valueEncoding: 'json'}, (err, kurssit) => {

      callback(kurssit);
   });
};


Kurssi.findByKey = (key, callback) => {

   db.get(key, {valueEncoding: 'json'}, (err, kurssi) => {

      callback(kurssi);
   });
};

