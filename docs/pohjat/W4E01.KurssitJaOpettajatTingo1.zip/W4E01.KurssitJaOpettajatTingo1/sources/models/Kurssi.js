
require('../configs/log')(module.filename);

const db = require('../configs/db_connection');

const Kurssi = {};
module.exports = Kurssi;


/**
 * Lukee kaikki kurssit tietokannasta nimen 
 * mukaisessa järjestyksessä
 * @param {Function} callback
 * @returns {undefined}
 */
Kurssi.findAll = (callback) => {

   db.kurssit.find().sort({'nimi': 1}).toArray((err, docs) => {
      callback(docs);
   });
};

/**
 * 
 * @param {Number} _id kurssin _id
 * @param {Function} callback
 * @returns {undefined}
 */
Kurssi.findByKey = (_id, callback) => {

   db.kurssit.findOne({'_id': _id}, (err, kurssi) => {

      //console.log('***', kurssi);

      if (kurssi.opettaja) {
         db.opettajat.findOne({'_id': kurssi.opettaja}, (err, opettaja) => {
            kurssi.opettaja = opettaja;
            callback(kurssi);
         });
      } else {
         callback(kurssi);
      }
   });
};

