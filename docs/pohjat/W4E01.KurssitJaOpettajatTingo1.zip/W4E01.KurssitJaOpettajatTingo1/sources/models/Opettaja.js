
log = require('../configs/log');
log(module.filename);


// TKJ2017k, Tehtävä 4.1

// Nimi: 
// OppNro: 


const db = require('../configs/db_connection');

const Opettaja = {};
module.exports = Opettaja;


/*
 * SELECT
 */


Opettaja.findAll = (callback) => {

   callback([]);

}; //Opettaja.findAll


Opettaja.findByKey = (_id, callback) => {

   callback({});

}; //Opettaja.findByKey


/*
 * INSERT
 */

Opettaja.create = (opettaja, callback) => {

   callback(2);

};


/*
 * UPDATE
 */

Opettaja.update = (opettaja, callback) => {

   callback(2);
   
};


/*
 * DELETE
 */

Opettaja.destroy = (_id, callback) => {

   callback();

};

