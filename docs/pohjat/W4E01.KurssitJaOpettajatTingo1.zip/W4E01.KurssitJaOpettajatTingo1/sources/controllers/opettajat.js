
const log = require('../configs/log');
log(module.filename);

// TKJ2017k, Tehtävä 4.1

// Nimi: 
// OppNro: 


const Opettaja = require('../models/Opettaja');

const router = require('express').Router();
module.exports = router;


/*
 * INSERT
 */

router.get('/insert', (req, res) => {

   res.render('opettaja_insert');
});


router.post('/insert', (req, res) => {

   if (req.body._cancel) {
      res.redirect('/opettajat');
      return;
   }

   delete req.body._insert;
   
   Opettaja.create(req.body, (_id) => {
      res.redirect(`/opettajat/${_id}`);
   });

});


/*
 * UPDATE
 */


router.get('/:_id/update', (req, res) => {

   Opettaja.findByKey(req.params._id, (opettaja) => {

      if (!opettaja) {
         res.render('opettaja_detail');
         return;
      }

      res.render('opettaja_update', {
         opettaja: opettaja
      });

   });
});


router.post('/update', (req, res) => {

   if (req.body._cancel) {
      res.redirect(`/opettajat/${req.body._id}`);
      return;
   }

   delete req.body._update;

   Opettaja.update(req.body, (_id) => {
      res.redirect(`/opettajat/${_id}`);
   });

});


/*
 * DELETE
 */


router.get('/:_id/delete', (req, res) => {

   Opettaja.findByKey(req.params._id, (opettaja) => {

      if (!opettaja) {
         res.render('opettaja_detail');
         return;
      }
              
      res.render('opettaja_delete', {
         opettaja: opettaja
      });
   });
});


router.post('/delete', (req, res) => {

   if (req.body._cancel) {
      res.redirect('/opettajat/' + req.body._id);
      return;
   }

   Opettaja.destroy(req.body._id, () => {
      res.redirect('/opettajat');
   });

});


/*
 * SELECT
 */

router.get('/', (req, res) => {

   Opettaja.findAll((opettajat) => {

      //log(module.filename, opettajat);

      res.render('opettaja_list', {
         opettajat: opettajat
      });

   });
});


router.get('/:_id', (req, res) => {

   Opettaja.findByKey(req.params._id, (opettaja) => {

      res.render('opettaja_detail', {
         opettaja: opettaja
      });
   });

});
