
const log = require('./log');
log(module.filename);

/* global __dirname */

const Engine = require('tingodb')();
const Database = __dirname + '/../../database';
const db = new Engine.Db(Database, {});

module.exports = {
   base: db,
   opettajat: db.collection('opettajat'),
   kurssit: db.collection('kurssit')
};

