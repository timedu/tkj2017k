
const log = (filename, msg) => {
   const ModuleName = require('path').parse(filename).name;
   console.log('***', ModuleName, msg ? ':' : '', msg || '');
};

module.exports = log;

