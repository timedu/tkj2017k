
/* global __dirname, Promise */

const _log = require('./log');
const log = (msg) => {
   _log(module.filename, msg);
};
log();

const csv = require('csvtojson');
const db = require('./db_connection');
const DataDir = `${__dirname}/db_seed`;


module.exports = () => {

   Promise.all([

      ensureCollectionIsEmpty('opettajat'),
      ensureCollectionIsEmpty('kurssit')

   ]).then(() => {

      Promise.all([

         insertCSVtoCollection('opettajat'),
         insertCSVtoCollection('kurssit')

      ]).then(dataArr => {

         // alustavat tiedot tietokanasta

         const opettajaArr = dataArr[0];
         const kurssiArr = dataArr[1];

         // rakennetaan yhteydet

         const opettajaMap = {}; // avaimena tunnus

         opettajaArr.forEach((opettaja) => {
//            opettaja.kurssit = [];
            opettajaMap[opettaja.tunnus] = opettaja;
            delete opettaja.tunnus;
         });

         kurssiArr.forEach((kurssi) => {
//            opettajaMap[kurssi.opettaja].kurssit.push(kurssi._id);
            kurssi.opettaja = opettajaMap[kurssi.opettaja]._id;
         });

         // talletetaan päivitetyt tiedot tietokantaan

         saveCollection('opettajat', opettajaArr);
         saveCollection('kurssit', kurssiArr);

      }, reason => {
         log(reason);
      });

   }, reason => {
      log(reason);
   });

};


/**
 * Lukee csv-tiedoston sisällön ja tallettaa sen rivit dokumenteiksi
 * tietokantaan
 * @param {String} collection kokoelma, johon tiedot talletetaan
 * @returns {Promise}
 */
function insertCSVtoCollection(collection) {

   return new Promise((resolve, reject) => {

      csv({delimiter: ';'}).fromFile(`${DataDir}/${collection}.csv`)

              .on('end_parsed', (objArr) => {

                 log(`${collection} csv read`);

                 db[collection].insert(objArr, (err, result) => {
                    resolve(result);
                 });

              })

              .on('error', (err) => {
                 reject(err);
              });
   });
}

/**
 * Tarkistaa, onko kokoelmassa dokmentteja
 * @param {type} collection
 * @returns {Promise}
 */
function ensureCollectionIsEmpty(collection) {

   return new Promise((resolve, reject) => {

      db[collection].find().toArray(function (err, docs) {
         if (docs.length) {
            reject(`db.${collection} already contains docs`);
         } else {
            resolve();
         }
      });
   });
}



/**
 * Tallettaa taulukon rivit kokoelmaan
 * @param {type} collection
 * @param {type} arr
 * @returns {undefined}
 */
function saveCollection(collection, arr) {

   arr.forEach((doc) => {
      db[collection].save(doc, () => {
         log(doc);
      });
   });

}


