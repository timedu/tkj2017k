
var assert = require('assert');

describe('Yksikkötestit', function () {

    it('- ei sisällä yksikkötestejä', function () {
        assert.equal(true, true);
    });

});

