

/*
 * Use Selenium Web Driver
 */

var test = require('selenium-webdriver/testing');
var webdriver = require('selenium-webdriver');
var until = webdriver.until;

/*
 * Use PhantomJS as Browser
 */

var phantomjs_exe = require('phantomjs-prebuilt').path;

var customPhantom = webdriver.Capabilities.phantomjs();
customPhantom.set("phantomjs.binary.path", phantomjs_exe);

var browser = new webdriver.Builder()
        .withCapabilities(customPhantom).build();

/*
 * Perform tests
 */

const ServerAddress = 'http://127.0.0.1:3000';

const URL1 = `/${Math.random()}`;
const URL2 = `/${Math.random()}`;

const ExpectedContent = (count, url) => {
    return `Hello ${count} from Node (${url})`;
};


test.describe('Sivutestit:', function () {

    // test.before(function () {});

    test.it('esittää ensimmäisellä pyynnöllä odotetun sisällön', function () {

        browser.get(ServerAddress + URL1);

        browser.wait(function () {
            return browser.getPageSource().then(function (source) {
                return source.includes(ExpectedContent(1, URL1));
            });
        }, 500);

    });

    test.it('kasvattaa laskuria seuraavilla pyynnöillä', function () {

        [2, 3].forEach((count) => {

            browser.get(ServerAddress + URL1);

            browser.wait(function () {
                return browser.getPageSource().then(function (source) {
                    return source.includes(ExpectedContent(count, URL1));
                });
            }, 500);
            
        });
    });

    test.it('siirtää laskurin alkuun pyynnöllä toiseen polkuun', function () {

        const URL = URL2;
        const ExpectedCount = 1;

        browser.get(`${ServerAddress}${URL}`);                
        browser.wait(function () {
            return browser.getPageSource().then(function (source) {
                return source.includes(ExpectedContent(ExpectedCount, URL));
            });
        }, 500);

    });

   test.it('jatkaa ensimmäisen polun laskurin askeltamista', function () {

        const URL = URL1;
        const ExpectedCount = 4;

        browser.get(`${ServerAddress}${URL}`);                
        browser.wait(function () {
            return browser.getPageSource().then(function (source) {
                return source.includes(ExpectedContent(ExpectedCount, URL));
            });
        }, 500);

    });

    // test.after(function () {});

});

