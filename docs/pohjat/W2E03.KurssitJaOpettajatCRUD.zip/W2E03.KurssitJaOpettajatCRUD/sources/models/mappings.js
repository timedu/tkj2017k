
module.exports = (DatabaseFile) => {
    
    var Sequelize = require('sequelize');

    var sequelize = new Sequelize('koulu', '', '', {
        dialect: 'sqlite',
        storage: DatabaseFile,
        define: {
            timestamps: false
        }
    });
    
        
    var Opettaja = sequelize.define('opettaja', {
        id: {
            type: Sequelize.DataTypes.INTEGER, 
            autoIncrement: true, 
            primaryKey: true
        },
        tunnus: Sequelize.DataTypes.STRING,
        etunimi: Sequelize.DataTypes.STRING,
        sukunimi: Sequelize.DataTypes.STRING
    }, {
        freezeTableName: true
    });

    var Kurssi = sequelize.define('kurssi', {
        id: {
            type: Sequelize.DataTypes.INTEGER, 
            autoIncrement: true, 
            primaryKey: true
        },
        tunnus: Sequelize.DataTypes.STRING,
        nimi: Sequelize.DataTypes.STRING,
        laajuus: Sequelize.DataTypes.STRING
    }, {
        freezeTableName: true
    });

    Kurssi.belongsTo(Opettaja, {foreignKey: 'opettaja_id', as: 'Opettaja'});
    Opettaja.hasMany(Kurssi, {foreignKey: 'opettaja_id', as: 'Kurssit'});

    sequelize.sync();

    global.Opettaja = Opettaja;
    global.Kurssi = Kurssi;
      
};
