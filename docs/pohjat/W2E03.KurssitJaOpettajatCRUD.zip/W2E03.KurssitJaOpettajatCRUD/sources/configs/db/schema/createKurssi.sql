CREATE TABLE kurssi (
   id       INTEGER PRIMARY KEY AUTOINCREMENT,
   tunnus   VARCHAR(10) UNIQUE NOT NULL,
   nimi     VARCHAR(30) UNIQUE NOT NULL,
   laajuus  VARCHAR(10),
   opettaja_id INTEGER
      REFERENCES opettaja (id)
      ON DELETE SET NULL
)
