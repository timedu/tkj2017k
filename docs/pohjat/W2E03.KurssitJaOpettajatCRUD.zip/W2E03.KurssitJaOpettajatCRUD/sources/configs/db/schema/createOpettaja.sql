CREATE TABLE opettaja (
   id           INTEGER PRIMARY KEY AUTOINCREMENT,
   tunnus       VARCHAR(10),
   sukunimi     VARCHAR(30) NOT NULL,
   etunimi      VARCHAR(30)
)
