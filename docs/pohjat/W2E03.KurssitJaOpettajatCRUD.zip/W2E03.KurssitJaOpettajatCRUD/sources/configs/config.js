

// TKJ2017k, Tehtävä 2.2

// Nimi: 
// OppNro: 


require('./db/db_config');

module.exports = (controllers) => {

    /*
     * express
     */

    const app = require('express')();

    /*
     * bodyParser
     */

    const bodyParser = require('body-parser');
    app.use(bodyParser.urlencoded({extended: false}));

    /*
     * Controllers
     */

    const ControllerPath = '../controllers';

    controllers.forEach((controller) => {
        require(`${ControllerPath}/${controller}`)(app);
    });


    /*
     * Handlebars
     */

    var handlebars = require('express-handlebars');


    app.engine('.hbs', handlebars({
        defaultLayout: 'main',
        extname: '.hbs',
        layoutsDir: 'sources/views/layouts/'
    }));
    app.set('view engine', '.hbs');
    app.set('views', __dirname + '/../views');


    /*
     * Method to Start
     */

    const hostname = '127.0.0.1';
    const port = 3000;

    return {
        run: () => {
            app.listen(port, hostname, () => {
                console.log(`Server running at http://${hostname}:${port}/`);
            });
        }
    };

};

