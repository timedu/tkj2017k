

// TKJ2017k, Tehtävä 2.3

// Nimi: 
// OppNro: 


module.exports = (app) => {

   /*
    * --------------------------------------------------------------
    * insert
    */

   // lomake

   app.get('/opettajat/insert', (req, res) => {

      res.send(req.url);
   });

   // lisäyksen suoritus

   app.post('/opettajat/insert', (req, res) => {

      res.redirect('/opettajat/insert');

   });


   /*
    * --------------------------------------------------------------
    * update
    */

   // lomake

   app.get('/opettajat/:id/update', (req, res) => {

      res.send(req.url);

   });

   // muutoksen suoritus

   app.post('/opettajat/update', (req, res) => {

      res.redirect('/opettajat/1/update');

   });


   /*
    * --------------------------------------------------------------
    * delete
    */

   // lomake

   app.get('/opettajat/:id/delete', (req, res) => {

      res.send(req.url);

   });

   // poiston suoritus

   app.post('/opettajat/delete', (req, res) => {

      res.redirect('/opettajat/1/delete');

   });



   /*
    * --------------------------------------------------------------
    * select
    */

   // luettelo

   app.get('/opettajat', function (req, res) {

      res.send(req.url);

   });

   // erittely

   app.get('/opettajat/:id', function (req, res) {

      res.send(req.url);
   });

};



