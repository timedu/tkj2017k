
/* global __dirname */

// TKJ2017k, Tehtävä 2.3

// Nimi: 
// OppNro: 


module.exports = (app) => {

    /*
     * --------------------------------------------------------------
     * insert
     */

    // lomake

    app.get('/kurssit/insert', (req, res) => {

        res.send(req.url);
    });

    // lisäyksen suoritus

    app.post('/kurssit/insert', (req, res) => {

        res.redirect('/kurssit/insert');
    });

    /*
     * --------------------------------------------------------------
     * update
     */

    // lomake

    app.get('/kurssit/:id/update', (req, res) => {

        global.Kurssi.findById(req.params.id).then((kurssi) => {

            if (!kurssi) {
                res.render('kurssi');
                return;
            }

            global.Opettaja.findAll({order: 'sukunimi'}).then((opettajat) => {

                // ao. option-elementin valinta
                opettajat.forEach((opettaja) => {
                    opettaja.selected = opettaja.id === kurssi.opettaja_id ? 'selected' : '';
                });

                res.render('kurssi_update', {
                    kurssi: kurssi,
                    opettajat: opettajat
                });

            });

        });
    });

    // muutoksen suoritus

    app.post('/kurssit/update', (req, res) => {

        if (req.body._cancel) {
            res.redirect('/kurssit/' + req.body.id);
            return;
        }

        global.Kurssi.findById(req.body.id).then((kurssi) => {

            if (!req.body.opettaja_id.length)
                req.body.opettaja_id = null;

            kurssi.update(req.body).then((kurssi) => {
                res.redirect('/kurssit/' + kurssi.id);
            });
        });

    });


    /*
     * --------------------------------------------------------------
     * delete
     */

    // lomake

    app.get('/kurssit/:id/delete', (req, res) => {

        res.send(req.url);
    });

    // poiston suoritus

    app.post('/kurssit/delete', (req, res) => {

        res.redirect('/kurssit/1/delete');
    });


    /*
     * --------------------------------------------------------------
     * select
     */

    // luettelo

    app.get('/kurssit', function (req, res) {

        res.send(req.url);
    });

    // erittely

    app.get('/kurssit/:id', function (req, res) {

        global.Kurssi.findById(req.params.id).then((kurssi) => {

            if (!kurssi) {
                res.render('kurssi');
                return;
            }

            kurssi.getOpettaja().then((opettaja) => {

                res.render('kurssi', {
                    kurssi: kurssi,
                    opettaja: opettaja
                });

            });
        });

    });

};

