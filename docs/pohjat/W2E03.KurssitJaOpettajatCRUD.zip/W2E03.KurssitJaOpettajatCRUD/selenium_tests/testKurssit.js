
var assert = require('assert');
var webdriver = require('selenium-webdriver');
var test = require('selenium-webdriver/testing');
var By = webdriver.By;

/*
 * Use PhantomJS as Browser
 */

var phantomjs_exe = require('phantomjs-prebuilt').path;
var customPhantom = webdriver.Capabilities.phantomjs();
customPhantom.set("phantomjs.binary.path", phantomjs_exe);
var browser = new webdriver.Builder()
        .withCapabilities(customPhantom).build();
/*
 * Execute Tests
 */

const ServerAddress = 'http://127.0.0.1:3000';


test.describe('(testKurssit:) testaa polkua "kurssit->kurssi->opettaja":', function () {

    test.it('kurssit-sivulla on odotettu sisältö', () => {

        browser.get(`${ServerAddress}/kurssit`).then(() => {

            const ExpectedH2Content = 'Kurssit';

            browser.findElement(By.css('h2')).getText().then((elementText) => {
                assert.ok(elementText.includes(ExpectedH2Content),
                        `h2-elementin sisältö: "${elementText}"; odotettu sisältö: "${ExpectedH2Content}"`);
            });


            const ExpectedLength = 15;
            const ExpectedA1Content = 'Mobiiliohjelmointi';
            const ExpectedA2Content = 'Ohjelmistoprojekti';
            const ExpectedA3Content = 'Ohjelmistotuotteen hallinta';

            browser.findElements(By.css('li a')).then((elements) => {

                assert.equal(elements.length, ExpectedLength,
                        `"li a"-elementien lukumäärä: "${elements.length}"; odotettu määrä: "${ExpectedLength}"`);

                elements[1].getText().then((elementText) => {
                    assert.ok(elementText.includes(ExpectedA1Content),
                            `2. a-elementin sisältö: "${elementText}"; odotettu sisältö: "${ExpectedA1Content}"`);
                });

                elements[2].getText().then((elementText) => {
                    assert.ok(elementText.includes(ExpectedA2Content),
                            `3. a-elementin sisältö: "${elementText}"; odotettu sisältö: "${ExpectedA2Content}"`);
                });

                elements[3].getText().then((elementText) => {
                    assert.ok(elementText.includes(ExpectedA3Content),
                            `4. a-elementin sisältö: "${elementText}"; odotettu sisältö: "${ExpectedA3Content}"`);
                });

            });

        });

    });// test.it

    test.it('kurssit-sivun linkin klikkaus vie kurssi-sivulle', () => {
        browser.get(`${ServerAddress}/kurssit`).then(() => {

            const ExpectedH2Content = 'Kurssi';
            const ExpectedCourse = ' Mobiiliohjelmointi';

            browser.findElements(By.css('li a')).then((elements) => {

                elements[1].click().then(() => {

                    browser.findElement(By.css('h2')).getText().then((elementText) => {
                        assert.equal(elementText, ExpectedH2Content,
                                `sivun otsikon (h2-elementti) sisältö: "${elementText}"; odotettu sisältö: "${ExpectedH2Content}"`);
                    });

                    browser.findElement(By.css('body')).getText().then((elementText) => {
                        assert.ok(elementText.includes(ExpectedCourse),
                                `sivulta pitäisi (sisältö: "${elementText}") pitäisi löytyä teksti: "${ExpectedCourse}"`);
                    });
                });
            });
        });
    });// test.it


    test.it('kurssi-sivulla on odotettu sisältö', () => {

        const CourseId = '8';

        const ExpectedH2Content = 'Kurssi';

        const ExpectedCourseMark = 'PLA-32820';
        const ExpectedCourseName = 'Mobiiliohjelmointi';
        const ExpectedSize = 'Laajuus: 5';
        const ExpectedInstructor = 'Mikama, Santtu';

        browser.get(`${ServerAddress}/kurssit/${CourseId}`).then(() => {

            browser.findElement(By.css('h2')).getText().then((elementText) => {
                assert.equal(elementText, ExpectedH2Content,
                        `sivun otsikon (h2-elementti) sisältö: "${elementText}"; odotettu sisältö: "${ExpectedH2Content}"`);
            });

            browser.findElement(By.css('body')).getText().then((elementText) => {

                assert.ok(elementText.includes(ExpectedCourseMark),
                        `sivulta pitäisi (sisältö: "${elementText}") pitäisi löytyä teksti: "${ExpectedCourseMark}"`);

                assert.ok(elementText.includes(ExpectedCourseName),
                        `sivulta pitäisi (sisältö: "${elementText}") pitäisi löytyä teksti: "${ExpectedCourseName}"`);

                assert.ok(elementText.includes(ExpectedSize),
                        `sivulta pitäisi (sisältö: "${elementText}") pitäisi löytyä teksti: "${ExpectedSize}"`);

                assert.ok(elementText.includes(ExpectedInstructor),
                        `sivulta pitäisi (sisältö: "${elementText}") pitäisi löytyä teksti: "${ExpectedInstructor}"`);

            });

        });
    });// test.it


    test.it('kurssi-sivun linkin klikkaus vie opettaja-sivulle', () => {

        const CourseId = '8';

        const ExpectedH2Content = 'Opettaja';

        const ExpectedFirstname = 'Santtu';
        const ExpectedLastname = 'Mikama';


        browser.get(`${ServerAddress}/kurssit/${CourseId}`).then(() => {

            browser.findElement(By.css('div a')).click().then(() => {

                browser.findElement(By.css('h2')).getText().then((elementText) => {
                    assert.equal(elementText, ExpectedH2Content,
                            `sivun otsikon (h2-elementti) sisältö: "${elementText}"; odotettu sisältö: "${ExpectedH2Content}"`);
                });

                browser.findElement(By.css('body')).getText().then((elementText) => {

                    assert.ok(elementText.includes(ExpectedFirstname),
                            `sivulta pitäisi (sisältö: "${elementText}") pitäisi löytyä teksti: "${ExpectedFirstname}"`);

                    assert.ok(elementText.includes(ExpectedLastname),
                            `sivulta pitäisi (sisältö: "${elementText}") pitäisi löytyä teksti: "${ExpectedLastname}"`);
                });

            });
        });
    });// test.it

});

