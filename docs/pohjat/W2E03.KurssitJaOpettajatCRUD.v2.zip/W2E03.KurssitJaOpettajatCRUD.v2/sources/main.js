

/* global __dirname */

// TKJ2017k, Tehtävä 2.3

// Nimi: 
// OppNro: 


const app = require('express')();

app.use(require('body-parser').urlencoded({extended: false}));

app.engine('.hbs', require('express-handlebars')({
   defaultLayout: 'main',
   extname: '.hbs',
   layoutsDir: 'sources/views/layouts/'
}));

app.set('view engine', '.hbs');
app.set('views', __dirname + '/views');


app.use('/kurssit', require('./controllers/kurssit'));
app.use('/opettajat', require('./controllers/opettajat'));

require('./configs/db_seed')(); // alustaa dataa tietokantaan


const hostname = '127.0.0.1';
const port = 3000;
const log = require('./configs/log');

app.listen(port, hostname, () => {
   log(module.filename, `server running at http://${hostname}:${port}/`);
});

