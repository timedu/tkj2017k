
require('./log')(module.filename);


const Sequelize = require('sequelize');

//require('./db_seed');

// const sqlite3 = require('sqlite3').verbose(); 

const db = new Sequelize('koulu', '', '', {
   dialect: 'sqlite',
   storage: 'database/koulu.sqlite',
   define: {
      timestamps: false
   }
});

// require('./db_seed')(); // alustaa datan tietokantaan

module.exports = db;



