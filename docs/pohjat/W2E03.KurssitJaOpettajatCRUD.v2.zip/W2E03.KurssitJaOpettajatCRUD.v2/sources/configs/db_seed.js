
const _log = require('./log');
const log = (msg) => {
    _log(module.filename, msg);
};
log();

const Opettaja = require('../models/Opettaja');
const Kurssi = require('../models/Kurssi');

const csv = require('csvtojson'); 

module.exports = () => {

    const DataDir = `${__dirname}/db_seed`;

    checkIfOpettajaHasRows();

    function checkIfOpettajaHasRows() {

        Opettaja.count().then((count) => {

            if (!count) {
                readOpettajatCSV();

            } else {
                log(`Opettaja already has ${count} row(s)`);
            }
        });
    }


    function readOpettajatCSV() {

        csv({delimiter: ';'}).fromFile(`${DataDir}/opettajat.csv`)
                .on('end_parsed', (objArr) => {
                    log('opettaja-data read');
                    insertOpettajat(objArr);
                })
                .on('error', (err) => {
                    log(err);
                });
    }


    function insertOpettajat(opettajatCSV) {

        Opettaja.bulkCreate(opettajatCSV).then((rows) => {
            log(`Opettaja : ${rows.length} row(s) created`);
            checkIfKurssiHasRows();
        });

    }

    function checkIfKurssiHasRows() {

        Kurssi.count().then((count) => {

            if (!count) {
                readKurssiCSV();

            } else {
                log(`Kurssi already has ${count} row(s)`);
            }
        });
    }


    function readKurssiCSV() {

        csv({delimiter: ';'}).fromFile(`${DataDir}/kurssit.csv`)
                .on('end_parsed', (objArr) => {
                    log('kurssi-data read');
                    insertKurssit(objArr);
                })
                .on('error', (err) => {
                    log(err);
                });
    }


    function insertKurssit(kurssitCSV) {

        Opettaja.findAll().then((rows) => {

            const opettajat = {};

            rows.forEach((row) => {
                opettajat[row.tunnus] = row;
            });

            kurssitCSV.forEach((kurssi) => {
                kurssi.opettaja_id = opettajat[kurssi.opettaja].id;
                delete kurssi.opettaja;
            });

            Kurssi.bulkCreate(kurssitCSV).then((rows) => {
                log(`Kurssi : ${rows.length} row(s) created`);
            });

        });

    }


};


