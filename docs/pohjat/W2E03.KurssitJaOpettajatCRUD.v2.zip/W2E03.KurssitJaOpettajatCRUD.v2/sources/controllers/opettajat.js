

// TKJ2017k, Tehtävä 2.3

// Nimi: 
// OppNro: 


module.exports = router = require('express').Router();

const OpettajaInsert = require('./opettajat/opettajat_insert');
const OpettajaUpdate = require('./opettajat/opettajat_update');
const OpettajaRemove = require('./opettajat/opettajat_remove');
const OpettajaSelect = require('./opettajat/opettajat_select');

router.get('/insert', OpettajaInsert.get);
router.post('/insert', OpettajaInsert.post);

router.get('/:id/update', OpettajaUpdate.get);
router.post('/update', OpettajaUpdate.post);

router.get('/:id/delete', OpettajaRemove.get);
router.post('/delete', OpettajaRemove.post);

router.get('/:id', OpettajaSelect.getOne);
router.get('/', OpettajaSelect.getAll);


//
//
//const Opettaja = require('../models/Opettaja');
//
//module.exports = router = require('express').Router();
//
//
///*
// * --------------------------------------------------------------
// * insert
// */
//
//// lomake
//
//router.get('/insert', (req, res) => {
//
////        res.send(req.url);
//
//   res.render('opettaja_insert');
//});
//
//
//// lisäyksen suoritus
//
//router.post('/insert', (req, res) => {
//
////        res.redirect('/opettajat/insert');
//
//   if (req.body._cancel) {
//      res.redirect('/opettajat');
//      return;
//   }
//
//   Opettaja.create(req.body).then((opettaja) => {
//      res.redirect('/opettajat/' + opettaja.id);
//   });
//
//});
//
//
///*
// * --------------------------------------------------------------
// * update
// */
//
//// lomake
//
//router.get('/:id/update', (req, res) => {
//
////      res.send(req.url);
//
//   Opettaja.findById(req.params.id).then((opettaja) => {
//
//      if (!opettaja) {
//         res.render('opettaja');
//         return;
//      }
//
//      res.render('opettaja_update', {
//         opettaja: opettaja
//      });
//
//   });
//});
//
//// muutoksen suoritus
//
//router.post('/update', (req, res) => {
//
////      res.redirect('/opettajat/1/update');
//
//   if (req.body._cancel) {
//      res.redirect('/opettajat/' + req.body.id);
//      return;
//   }
//
//   Opettaja.findById(req.body.id).then((opettaja) => {
//
//      opettaja.update(req.body).then((opettaja) => {
//         res.redirect('/opettajat/' + opettaja.id);
//      });
//   });
//
//});
//
//
///*
// * --------------------------------------------------------------
// * delete
// */
//
//// lomake
//
//router.get('/:id/delete', (req, res) => {
//
////      res.send(req.url);
//
//   Opettaja.findById(req.params.id).then((opettaja) => {
//
//      if (!opettaja) {
//         res.render('opettaja');
//         return;
//      }
//
//      res.render('opettaja_delete', {
//         opettaja: opettaja
//      });
//   });
//});
//
//
//// poiston suoritus
//
//router.post('/delete', (req, res) => {
//
////      res.redirect('/opettajat/1/delete');
//
//   if (req.body._cancel) {
//      res.redirect('/opettajat/' + req.body.id);
//      return;
//   }
//
//   Opettaja.findById(req.body.id).then((opettaja) => {
//      return opettaja.destroy();
//   }).then(() => {
//      res.redirect('/opettajat');
//   });
//
//});
//
//
//
///*
// * --------------------------------------------------------------
// * select
// */
//
//// luettelo
//
//router.get('/', function (req, res) {
//
////      res.send(req.url);
//
//   Opettaja.findAll({order: 'sukunimi'}).then(function (opettajat) {
//      res.render('opettaja_list', {
//         opettajat: opettajat
//      });
//   });
//
//});
//
//
//// erittely
//
//router.get('/:id', function (req, res) {
//
////      res.send(req.url);
//
//   Opettaja.findById(req.params.id).then((opettaja) => {
//
//      if (!opettaja) {
//         res.render('opettaja');
//         return;
//      }
//
//      opettaja.getKurssit({order: 'nimi'}).then((kurssit) => {
//
//         res.render('opettaja', {
//            opettaja: opettaja,
//            kurssit: kurssit
//         });
//
//      });
//
//   });
//
//});
//
//
//
//
