

// TKJ2017k, Tehtävä 2.3

// Nimi: 
// OppNro: 


module.exports = router = require('express').Router();

const OpettajaInsert = require('./opettajat/opettajat_insert');
const OpettajaUpdate = require('./opettajat/opettajat_update');
const OpettajaRemove = require('./opettajat/opettajat_remove');
const OpettajaSelect = require('./opettajat/opettajat_select');

router.get('/insert', OpettajaInsert.get);
router.post('/insert', OpettajaInsert.post);

router.get('/:id/update', OpettajaUpdate.get);
router.post('/update', OpettajaUpdate.post);

router.get('/:id/delete', OpettajaRemove.get);
router.post('/delete', OpettajaRemove.post);

router.get('/:id', OpettajaSelect.getOne);
router.get('/', OpettajaSelect.getAll);

