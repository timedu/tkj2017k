
// TKJ2017k, Tehtävä 2.3

// Nimi: 
// OppNro: 


const Kurssi = require('../../models/Kurssi');
const Opettaja = require('../../models/Opettaja');

module.exports = update = {};


// lomakesivu

update.get = (req, res) => {

   Kurssi.findById(req.params.id).then((kurssi) => {

      if (!kurssi) {
         res.render('kurssi');
         return;
      }

      Opettaja.findAll({order: 'sukunimi'}).then((opettajat) => {

         // ao. option-elementin merkintä valituksi
         opettajat.forEach((opettaja) => {
            opettaja.selected = opettaja.id === kurssi.opettaja_id ? 'selected' : '';
         });

         res.render('kurssi_update', {
            kurssi: kurssi,
            opettajat: opettajat
         });

      });

   });
};


// muutoksen suoritus

update.post = (req, res) => {

   if (req.body._cancel) {
      res.redirect('/kurssit/' + req.body.id);
      return;
   }

   Kurssi.findById(req.body.id).then((kurssi) => {

      if (!req.body.opettaja_id.length)
         req.body.opettaja_id = null;

      kurssi.update(req.body).then((kurssi) => {
         res.redirect('/kurssit/' + kurssi.id);
      });
   });

};

