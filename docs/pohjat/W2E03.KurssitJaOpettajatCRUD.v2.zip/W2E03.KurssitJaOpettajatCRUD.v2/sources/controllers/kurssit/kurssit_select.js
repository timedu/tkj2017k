
// TKJ2017k, Tehtävä 2.3

// Nimi: 
// OppNro: 


const Kurssi = require('../../models/Kurssi');


module.exports = select = {};


// luettelo

select.getAll = function (req, res) {

      res.send(req.url);

};


// erittely

select.getOne = function (req, res) {

   Kurssi.findById(req.params.id).then((kurssi) => {

      if (!kurssi) {
         res.render('kurssi');
         return;
      }

      kurssi.getOpettaja().then((opettaja) => {

         res.render('kurssi', {
            kurssi: kurssi,
            opettaja: opettaja
         });

      });
   });

};



