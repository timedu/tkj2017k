
// TKJ2017k, Tehtävä 2.3

// Nimi: 
// OppNro: 

const Kurssi = require('../../models/Kurssi');
const Opettaja = require('../../models/Opettaja');

module.exports = insert = {};


// lomake

insert.get = (req, res) => {

      res.send(req.url);

};


// lisäyksen suoritus

insert.post = (req, res) => {

      res.redirect('/kurssit/insert');


};


