
// TKJ2017k, Tehtävä 2.3

// Nimi: 
// OppNro: 


const Kurssi = require('../../models/Kurssi');
const Opettaja = require('../../models/Opettaja');

module.exports = remove = {};


// lomakesivu

remove.get = (req, res) => {

      res.send(req.url);

};


// poiston suoritus

remove.post = (req, res) => {

      res.redirect('/kurssit/1/delete');

};

