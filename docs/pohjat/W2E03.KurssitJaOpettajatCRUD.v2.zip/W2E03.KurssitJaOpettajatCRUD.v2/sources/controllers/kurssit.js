
// TKJ2017k, Tehtävä 2.3

// Nimi: 
// OppNro: 

module.exports = router = require('express').Router();

const KurssiInsert = require('./kurssit/kurssit_insert');
const KurssiUpdate = require('./kurssit/kurssit_update');
const KurssiRemove = require('./kurssit/kurssit_remove');
const KurssiSelect = require('./kurssit/kurssit_select');

router.get('/insert', KurssiInsert.get);
router.post('/insert', KurssiInsert.post);

router.get('/:id/update', KurssiUpdate.get);
router.post('/update', KurssiUpdate.post);

router.get('/:id/delete', KurssiRemove.get);
router.post('/delete', KurssiRemove.post);

router.get('/:id', KurssiSelect.getOne);
router.get('/', KurssiSelect.getAll);

