

// TKJ2017k, Tehtävä 2.3

// Nimi: 
// OppNro: 


const Opettaja = require('../../models/Opettaja');

module.exports = update = {};


// lomake

update.get = (req, res) => {

   res.send(req.url);

};


// muutoksen suoritus

update.post = (req, res) => {

   res.redirect('/opettajat/1/update');

};

