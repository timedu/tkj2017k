

// TKJ2017k, Tehtävä 2.3

// Nimi: 
// OppNro: 



const Opettaja = require('../../models/Opettaja');

module.exports = select = {};



// luettelo

select.getAll = function (req, res) {

   res.send(req.url);

};


// erittely

select.getOne = function (req, res) {

   res.send(req.url);

};




