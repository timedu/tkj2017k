
require('../configs/log')(module.filename);

const db = require('../configs/db_connection');
const DataTypes = db.Sequelize.DataTypes;

const Opettaja = db.define('opettaja', {
   id: {
      type: DataTypes.INTEGER,
      autoIncrement: true,
      primaryKey: true
   },
   tunnus: DataTypes.STRING,
   etunimi: DataTypes.STRING,
   sukunimi: DataTypes.STRING
}, {
   freezeTableName: true
});

module.exports = Opettaja;

