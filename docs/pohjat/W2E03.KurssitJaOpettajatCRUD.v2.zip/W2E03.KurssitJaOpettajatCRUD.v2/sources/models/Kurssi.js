
require('../configs/log')(module.filename);


const db = require('../configs/db_connection');
const Opettaja = require('./Opettaja');

const DataTypes = db.Sequelize.DataTypes;


const Kurssi = db.define('kurssi', {
   id: {
      type: DataTypes.INTEGER,
      autoIncrement: true,
      primaryKey: true
   },
   tunnus: DataTypes.STRING,
   nimi: DataTypes.STRING,
   laajuus: DataTypes.STRING
}, {
   freezeTableName: true
});

Kurssi.belongsTo(Opettaja, {foreignKey: 'opettaja_id', as: 'Opettaja'});
Opettaja.hasMany(Kurssi, {foreignKey: 'opettaja_id', as: 'Kurssit'});
db.sync();

module.exports = Kurssi;

