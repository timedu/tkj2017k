
const log = require('../configs/log');
log(module.filename);


// TKJ2017k, Tehtävä 4.3

// Nimi: 
// OppNro: 


const Opettaja = require('../models/Opettaja');

const router = require('express').Router();
module.exports = router;


router.get('/', (req, res) => {

   Opettaja.findAll((opettajat) => {

      res.render('opettaja_list', {
         opettajat: opettajat
      });

   });
});


router.get('/:_id', (req, res) => {

   Opettaja.findByKey(req.params._id, (opettaja) => {

      res.render('opettaja_detail', {
         opettaja: opettaja
      });
   });

});
