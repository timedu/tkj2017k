
log = require('../configs/log');
log(module.filename);


// TKJ2017k, Tehtävä 4.3

// Nimi: 
// OppNro: 


const ObjectID = require('mongodb').ObjectID;
const mongo = require('../configs/db_connection');

const Kurssi = {};
module.exports = Kurssi;


/**
 * Lukee kaikki kurssit tietokannasta nimen 
 * mukaisessa järjestyksessä
 * @param {Function} callback
 * @returns {undefined}
 */
Kurssi.findAll = (callback) => {

    log(module.filename, 'findAll');
    callback([]);

};


/**
 * Lukee kurssin sen tietokantatunnuksen perusteella
 * @param {String} _id kurssin _id merkkijonona
 * @param {Function} callback
 * @returns {undefined}
 */
Kurssi.findByKey = (_id, callback) => {

    log(module.filename, 'findByKey');
    callback({});


};

