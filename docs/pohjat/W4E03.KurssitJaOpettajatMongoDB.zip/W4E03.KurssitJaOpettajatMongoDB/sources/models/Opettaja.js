
log = require('../configs/log');
log(module.filename);


// TKJ2017k, Tehtävä 4.3

// Nimi: 
// OppNro: 


const ObjectID = require('mongodb').ObjectID;
const mongo = require('../configs/db_connection');


const Opettaja = {};
module.exports = Opettaja;


Opettaja.findAll = (callback) => {

    log(module.filename, 'findAll');
    callback([]);

};


Opettaja.findByKey = (_id, callback) => {
   
    log(module.filename, 'findByKey');
    callback({});
   
}; 


