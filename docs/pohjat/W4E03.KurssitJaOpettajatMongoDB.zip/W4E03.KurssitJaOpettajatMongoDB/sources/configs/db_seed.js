
/* global __dirname, Promise */

const _log = require('./log');
const log = (msg) => {
   _log(module.filename, msg);
};
log();

const csv = require('csvtojson');
const mongo = require('./db_connection');
const DataDir = `${__dirname}/db_seed`;


module.exports = () => {
};


//module.exports = () => {
//   mongo((db) => {
//
//      Promise.all([
//
//         ensureCollectionIsEmpty('opettajat', db),
//         ensureCollectionIsEmpty('kurssit', db)
//
//      ]).then(() => {
//
//         Promise.all([
//
//            insertCSVtoCollection('opettajat', db),
//            insertCSVtoCollection('kurssit', db)
//
//         ]).then(dataArr => {
//
//            // alustavat tiedot tietokannasta
//
//            const opettajaArr = dataArr[0].ops;
//            const kurssiArr = dataArr[1].ops;
//
////            log(opettajaArr);
////            log(kurssiArr);
//
//            // rakennetaan yhteydet
//
//            const opettajaMap = {}; // avaimena tunnus
//
//            opettajaArr.forEach((opettaja) => {
//               opettajaMap[opettaja.tunnus] = opettaja;
//               delete opettaja.tunnus;
//            });
//
//            kurssiArr.forEach((kurssi) => {
//               kurssi.opettaja_id = opettajaMap[kurssi.opettaja]._id;
//               delete kurssi.opettaja;
//            });
//
//            // talletetaan päivitetyt tiedot tietokantaan
//
////            log(opettajaArr);
////            log(kurssiArr);
//
//            saveCollection('opettajat', opettajaArr, db);
//            saveCollection('kurssit', kurssiArr, db);
//
//         }, reason => {
//            log(reason);
//            db.close();
//         });
//
//      }, reason => {
//         log(reason);
//         db.close();
//      });
//
//   });// mongo
//};


/*
 * Lukee csv-tiedoston sisällön ja tallettaa sen rivit dokumenteiksi
 * tietokantaan
 */

function insertCSVtoCollection(colName, db) {

   return new Promise((resolve, reject) => {

      csv({delimiter: ';'}).fromFile(`${DataDir}/${colName}.csv`)

              .on('end_parsed', (objArr) => {
                 log(`${colName} csv read`);
                 db.collection(colName).insert(objArr, (err, result) => {
                    resolve(result);
                 });
              })
              .on('error', (err) => {
                 reject(err);
              });
   });
}


/*
 * Tarkistaa, onko kokoelmassa dokmentteja
 */

function ensureCollectionIsEmpty(colName, db) {

   return new Promise((resolve, reject) => {

      const collection = db.collection(colName);

//      collection.find().toArray(function (err, docs) {
      collection.count({}, function (err, count) {
//         if (docs.length) {
         if (count) {
            reject(`collection ${colName} already contains docs`);
         } else {
            resolve();
         }
      });

   });
}


/*
 * Tallettaa taulukon rivit kokoelmaan
 */

function saveCollection(colName, arr, db) {

   const collection = db.collection(colName);

   arr.forEach((doc) => {
      collection.save(doc, () => {
         log(doc);
      });
   });

}

