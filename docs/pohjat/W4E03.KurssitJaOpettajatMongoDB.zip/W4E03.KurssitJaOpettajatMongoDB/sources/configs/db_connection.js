
const log = require('./log');
log(module.filename);


// nämä tunnisteet moodlesta
const dbuser = '';
const dbpassword = '';
const url = ``;
// 


const MongoClient = require('mongodb').MongoClient;

module.exports = (run) => {

   MongoClient.connect(url, function (err, db) {

      if (!err) {
         
         // log(module.filename, "connected to mongo server");
         run(db);
         
      } else {
         
         log(module.filename, "mongo connection failed");
         log(module.filename, err);         
      }
      
   });
};
