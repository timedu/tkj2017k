

var assert = require('assert');

// Testattava moduuli

var count = require('../sources/counter');

// Testien suoritus

const URL1 = '/abc';
const URL2 = '/def';

describe('Yksikkötestit', function () {

    it(`palauttaa ensimmäisellä kutsulla arvon 1 (parametri: "${URL1}")`, function () {

        const URL = URL1;
        const ExpectedCount = 1;

        assert.equal(count(URL), ExpectedCount);
    });


    it(`alkeltaa paluuarvoa seuraavilla kutsuilla (parametri: "${URL1}"`, function () {

        const URL = URL1;
        [2, 3].forEach((ExpectedCount) => {
            assert.equal(count(URL), ExpectedCount);
        });
    });

    it(`palauttaa ensimmäisellä kutsulla arvon 1 (parametri: "${URL2}")`, function () {

        const URL = URL2;
        const ExpectedCount = 1;

        assert.equal(count(URL), ExpectedCount);
    });

    it(`jatkaa laskurin askeltamista (parametri: "${URL1}")`, function () {

        const URL = URL1;
        const ExpectedCount = 4;

        assert.equal(count(URL), ExpectedCount);
    });

});

