
/* global __dirname */

// TKJ2017k, Tehtävä 1.3

// Nimi: 
// OppNro: 


var app = require('express')();
var count = require('./counter');

var handlebars = require('express-handlebars');
app.engine('.hbs', handlebars({
    defaultLayout: 'main',
    extname: '.hbs',
    layoutsDir: 'sources/views/layouts/'
}));
app.set('view engine', '.hbs');
app.set('views', __dirname + '/views'); // 


app.use(function (req, res) {
    res.send('Hello Handlebars');
});


const hostname = '127.0.0.1', port = 3000;
app.listen(port, hostname, () => {
    console.log(`Server running at http://${hostname}:${port}/`);
});


