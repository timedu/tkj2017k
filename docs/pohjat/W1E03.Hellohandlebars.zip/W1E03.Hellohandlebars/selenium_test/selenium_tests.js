
// TODO sisältötestit funktioon (toistuva sisältö)

var assert = require('assert');
/*
 * Use Selenium Web Driver
 */

var test = require('selenium-webdriver/testing');
var webdriver = require('selenium-webdriver');
var until = webdriver.until;
var By = webdriver.By;
/*
 * Use PhantomJS as Browser
 */

var phantomjs_exe = require('phantomjs-prebuilt').path;
var customPhantom = webdriver.Capabilities.phantomjs();
customPhantom.set("phantomjs.binary.path", phantomjs_exe);
var browser = new webdriver.Builder()
        .withCapabilities(customPhantom).build();
/*
 * Perform tests
 */

const Timeout = 500;
const ServerAddress = 'http://127.0.0.1:3000';
const URL0 = `/${Math.random()}`;
const URL1 = `/${Math.random()}`;
const URL2 = `/${Math.random()}`;
const ExpectedContent = (count, url) => {
    return `Hello ${count} from Handlebars (${url})`;
};
const ErrorMessage = (expectedContent) => {
    return `Sivulta ei löydy tekstiä "${expectedContent}".`;
};
const ExpectedTitle = "Hello Handlebars";
test.describe('Selenium-testit:', function () {

    // test.before(function () {});

    test.it(`asettaa "title"-elementin sisällöksi "${ExpectedTitle}"`, () => {

        browser.get(`${ServerAddress}${URL0}`).then(() => {
            browser.getTitle().then(function (title) {
                assert.ok(title.includes(ExpectedTitle),
                        `"title"-elementin sisältönä on "${title}"`);
            });
        });
    });


    test.it(`esittää ensimmäisellä pyynnöllä odotetun sisällön'`, () => {

        const URL = URL1;
        const ExpectedCount = 1;
        var content = ExpectedContent(ExpectedCount, URL);

        browser.get(`${ServerAddress}${URL}`).then(() => {
            browser.findElement(By.css('p')).getText().then((elementText) => {
                assert.ok(elementText.includes(content),
                        `elementin sisältö: "${elementText}"; odotettu sisältö: "${content}"`);
            });
        });

    });


    test.it('kasvattaa laskuria seuraavilla pyynnöillä', function () {

        const URL = URL1;
        [2, 3].forEach((count) => {

            var ExpectedCount = count;
            var content = ExpectedContent(ExpectedCount, URL);

            browser.get(`${ServerAddress}${URL}`).then(() => {
                browser.findElement(By.css('p')).getText().then((elementText) => {
                    assert.ok(elementText.includes(content),
                            `elementin sisältö: "${elementText}"; odotettu sisältö: "${content}"`);
                });
            });
        });
    });


    test.it('siirtää laskurin alkuun pyynnöllä toiseen polkuun', function () {

        const URL = URL2;
        const ExpectedCount = 1;
        var content = ExpectedContent(ExpectedCount, URL);

        browser.get(`${ServerAddress}${URL}`).then(() => {
            browser.findElement(By.css('p')).getText().then((elementText) => {
                assert.ok(elementText.includes(content),
                        `elementin sisältö: "${elementText}"; odotettu sisältö: "${content}"`);
            });
        });

    });


    test.it('jatkaa ensimmäisen polun laskurin askeltamista', function () {

        const URL = URL1;
        const ExpectedCount = 4;
        var content = ExpectedContent(ExpectedCount, URL);
        
        browser.get(`${ServerAddress}${URL}`).then(() => {
            browser.findElement(By.css('p')).getText().then((elementText) => {
                assert.ok(elementText.includes(content),
                        `elementin sisältö: "${elementText}"; odotettu sisältö: "${content}"`);
            });
        });
                
    });
    
    // test.after(function () {});

});

