

var requests = [];

module.exports = function (url) {
    return 9;
};
