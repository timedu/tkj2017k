
// TKJ2017k, Tehtävä 1.3

// Nimi: 
// OppNro: 


var app = require('express')();
var count = require('./counter');


var handlebars = require('express-handlebars');
app.engine('handlebars', handlebars({defaultLayout: 'main'}));
app.set('view engine', 'handlebars');


app.use(function(req, res)  {
    res.send('Hello Handlebars');
});


const hostname = '127.0.0.1', port = 3000;
app.listen(port, hostname, () => {
    console.log(`Server running at http://${hostname}:${port}/`);
});


