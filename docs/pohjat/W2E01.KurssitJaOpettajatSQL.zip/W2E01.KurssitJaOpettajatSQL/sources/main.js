

// TKJ2017k, Tehtävä 2.1

// Nimi: 
// OppNro: 

const Controllers = [
    'kurssiController',
    'opettajaController'
];

require('./configs/config')(Controllers).run();

