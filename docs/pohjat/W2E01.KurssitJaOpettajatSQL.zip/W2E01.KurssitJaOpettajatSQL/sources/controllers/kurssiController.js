

// TKJ2017k, Tehtävä 2.1

// Nimi: 
// OppNro: 


const SelectOneKurssi = '                       \
SELECT                                          \
    k.*,                                        \
    o.etunimi AS opettaja_etunimi,              \
    o.sukunimi AS opettaja_sukunimi             \
FROM kurssi AS k LEFT OUTER JOIN opettaja AS o  \
    ON k.opettaja_id = o.id                     \
WHERE k.tunnus = ?';


module.exports = (app) => {

    app.get('/kurssit', function (req, res) {
        
        res.render('kurssiluettelo');
        
    });


    app.get('/kurssit/:tunnus', function (req, res) {

        global.db.get(SelectOneKurssi, req.params.tunnus, (err, row) => {
            res.render('kurssi', {
                kurssi: row
            });
        });

    });

};

