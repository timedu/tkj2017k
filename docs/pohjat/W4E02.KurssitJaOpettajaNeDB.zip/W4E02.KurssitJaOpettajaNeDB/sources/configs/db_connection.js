
const log = require('./log');
log(module.filename);

/* global __dirname */

const Database = __dirname + '/../../database/koulu';

const Datastore = require('nedb');
const db = new Datastore({ filename: Database, autoload: true });

module.exports = db;

