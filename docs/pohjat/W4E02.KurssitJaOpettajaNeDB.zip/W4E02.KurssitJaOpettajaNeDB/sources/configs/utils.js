


/**
 * Lajitelelee oliotaulukon olion ominaisuuden mukaiseen aakkosjärjestykseen
 * @param {String} p ominaisuus, jonka mukaan lajittelu tapahtuu
 * @param {Array} ar lajiteltava taulukko
 * @returns {Array} lajiteltu taulukko
 */
const sortBy = (p, ar) => {
   return ar.sort((a, b) => {
      return a[p] <= b[p] ? -1 : 1;
   });
};

const log = (filename, msg) => {
   const ModuleName = require('path').parse(filename).name;
   console.log('***', ModuleName, msg ? ':' : '', msg || '');
};


module.exports = {
   sortBy: sortBy,
   log: log
};
