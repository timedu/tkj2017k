
/* global __dirname, Promise */

const _log = require('./log');
const log = (msg) => {
   _log(module.filename, msg);
};
log();

const cuid = require('cuid');
const csv = require('csvtojson');
const db = require('./db_connection');
const DataDir = `${__dirname}/db_seed`;


module.exports = () => {

   Promise.all([

      ensureDatastoreIsEmpty()

   ]).then(() => {

      Promise.all([

         readCSVFile('opettajat'),
         readCSVFile('kurssit')

      ]).then(dataArr => {

         // alustavat tiedot tietokanasta

         const opettajaArr = dataArr[0];
         const kurssiArr = dataArr[1];

         // rakennetaan redundanssi

         const opettajaMap = {}; // avaimena tunnus (ks. csv)

         opettajaArr.forEach((opettaja) => {
            opettaja.kurssit = [];
            opettajaMap[opettaja.tunnus] = opettaja;
            delete opettaja.tunnus;
         });

         kurssiArr.forEach((kurssi) => {
            kurssi.cuid = cuid();
            opettajaMap[kurssi.opettaja].kurssit.push(kurssi);
            delete kurssi.opettaja;
         });

         // log(JSON.stringify(opettajaArr));

         db.insert(opettajaArr,(err)=>{
            if (!err) {
               log('data stored');
            }
         });

         
      }, reason => {
         log(reason);
      });

   }, reason => {
      log(reason);
   });

};



function readCSVFile(collection) {

   return new Promise((resolve, reject) => {

      csv({delimiter: ';'}).fromFile(`${DataDir}/${collection}.csv`)
              .on('end_parsed', (objArr) => {
                 log(`${collection} csv read`);
                 resolve(objArr);
              })
              .on('error', (err) => {
                 reject(err);
              });
   });
}




function ensureDatastoreIsEmpty() {

   return new Promise((resolve, reject) => {

      db.count({},(err, count) => {
         if (count) {
            reject('datastore already contains docs');
         } else {
            resolve();
         }
      });

   });
}



