
const sortBy = require('../configs/utils').sortBy;
const log = require('../configs/utils').log;


// TKJ2017k, Tehtävä 4.2

// Nimi: 
// OppNro: 


const db = require('../configs/db_connection');

const Opettaja = {};
module.exports = Opettaja;



Opettaja.findAll = (callback) => {

   callback([]);

};


Opettaja.findByKey = (_id, callback) => {

   callback({});

};


