
const sortBy = require('../configs/utils').sortBy;
const log = require('../configs/utils').log;


// TKJ2017k, Tehtävä 4.2

// Nimi: 
// OppNro: 


const db = require('../configs/db_connection');

const Kurssi = {};
module.exports = Kurssi;


Kurssi.findAll = (callback) => {

   callback([]);
   
};


Kurssi.findByKey = (cuid, callback) => {

   callback({});

};


