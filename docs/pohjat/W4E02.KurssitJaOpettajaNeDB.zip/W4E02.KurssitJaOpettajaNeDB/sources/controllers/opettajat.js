
const log = require('../configs/log');
log(module.filename);

// TKJ2017k, Tehtävä 4.2

// Nimi: 
// OppNro: 


const Opettaja = require('../models/Opettaja');

const router = require('express').Router();
module.exports = router;



router.get('/', (req, res) => {

   Opettaja.findAll((opettajat) => {

      //log(module.filename, opettajat);

      res.render('opettaja_list', {
         opettajat: opettajat
      });

   });
});


router.get('/:_id', (req, res) => {

   Opettaja.findByKey(req.params._id, (opettaja) => {

//      log(module.filename, opettaja);

      res.render('opettaja_detail', {
         opettaja: opettaja
      });
   });

});
