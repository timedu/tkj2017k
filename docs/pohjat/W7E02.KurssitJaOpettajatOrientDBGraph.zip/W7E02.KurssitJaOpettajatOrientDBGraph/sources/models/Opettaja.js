
const log = (msg) => {
   require('../configs/utils').log(module.filename, msg);
};
log();


// TKJ2017k, Tehtävä 7.2

// Nimi: 
// OppNro: 


const db = require('../configs/db_connection');

const Opettaja = {};
module.exports = Opettaja;


const FindAllOpettajat = '\
SELECT @RID.asString().substring(1) AS key, sukunimi, etunimi \
FROM Opettaja \
ORDER BY sukunimi';

Opettaja.findAll = (callback) => {

   callback([]);
};


const FindOpettajaByKey = '\
SELECT \
   @RID.substring(1) AS key, \
   sukunimi, \
   etunimi \
FROM Opettaja \
WHERE @RID = :rid';

const FindKurssitUsingEdge = '\
SELECT \
  in.nimi AS nimi,    \
  in.@RID.substring(1) AS key \
FROM Opettaa \
WHERE out = :opettaja_rid \
ORDER BY nimi ';

Opettaja.findByKey = (opettaja_key, callback) => {

   callback({});

};

