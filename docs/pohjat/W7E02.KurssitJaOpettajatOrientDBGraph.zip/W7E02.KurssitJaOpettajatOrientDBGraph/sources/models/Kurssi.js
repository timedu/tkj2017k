
/* global Promise */

const log = (msg) => {
   require('../configs/utils').log(module.filename, msg);
};
log();


// TKJ2017k, Tehtävä 7.2

// Nimi: 
// OppNro: 


const db = require('../configs/db_connection');

const Kurssi = {};
module.exports = Kurssi;


const FindAllKurssit = '\
SELECT @RID.substring(1) AS key, nimi \
FROM Kurssi \
ORDER BY nimi';


Kurssi.findAll = (callback) => {

   callback([]);
};


const FindOpettajaUsingEdge = '';
const FindValittomatEsitiedot = '';
const FindEsitietoKursseille = '';
const TraverseMuutEsitiedot = '';

Kurssi.findByKey = (kurssi_key, callback) => {

   callback({});
   return;

   db.record.get('#' + kurssi_key).then(kurssi => {

      Promise.all([

         db.query(FindOpettajaUsingEdge, {
            params: {kurssi_rid: kurssi['@rid']}
         }),
         db.query(FindValittomatEsitiedot, {
            params: {kurssi_rid: kurssi['@rid']}
         }),
         db.query(FindEsitietoKursseille, {
            params: {kurssi_rid: kurssi['@rid']}
         }),
         db.query(TraverseMuutEsitiedot, {
            params: {kurssi_rid: kurssi['@rid']}
         })

      ]).then(resArr => {

         kurssi.opettaja = resArr[0][0];
         kurssi.valittomat_esitiedot = resArr[1];
         kurssi.esitieto_kursseille = resArr[2];
         kurssi.muut_esitiedot = resArr[3];

         callback(kurssi);

      }).catch(error => {
         log(error);
         callback({});
      });
   }).catch(error => {
      log(error);
      callback({});
   });
};

