
const log = (msg) => {
   require('../configs/utils').log(module.filename, msg);
};
log();


const Opettaja = require('../models/Opettaja');

module.exports = router = require('express').Router();



router.get('/', (req, res) => {

   Opettaja.findAll((opettajat) => {

      res.render('opettaja_list', {
         opettajat: opettajat
      });

   });
});



router.get('/:key', (req, res) => {


   Opettaja.findByKey(req.params.key, (opettaja) => {

      res.render('opettaja_detail', {
         opettaja: opettaja
      });
   });

});







