


function log(msg) {
    console.log('*** dbConfig:', msg + '.');
}


log('dbconfig started');

/*
 * tarvittavat moduulit 
 */
const fs = require('fs'); // tiedostojen käsittely
const csv = require('csvtojson'); // csv-tiedoston muunnos js-objektiksi
const sqlite3 = require('sqlite3').verbose(); // sqlite-tietokanta
/*
 * luettavien tiedostojen hakemistot
 */
const DBConfigDir = __dirname;
const SchemaDir = `${DBConfigDir}/schema`; // create table -komennot
const DataDir = `${DBConfigDir}/data`; // alustusdata


// tietokanta projektin database-hakemistossa
const DatabaseFile = __dirname + '/../../../database/koulu.sqlite';

// luodaan tieokanta, jos sitä ei vielä ole
if (!fs.existsSync(DatabaseFile)) {

    /*
     * luetaan taulujen perustamiskomennot tietostoista
     */
    const CreateOpettajaStatement = fs.readFileSync(`${SchemaDir}/createOpettaja.sql`, 'utf8');
    const CreateKurssiStatement = fs.readFileSync(`${SchemaDir}/createKurssi.sql`, 'utf8');
    /*
     * insert- ja update-komennot
     */
    const InsertOpettajaStatement = '\
INSERT INTO opettaja(tunnus, sukunimi, etunimi) \
VALUES (?,?,?)';

    const InsertKurssiStatement = '\
INSERT INTO kurssi(tunnus, nimi, laajuus) \
VALUES (?,?,?)';

    const UpdateKurssiForeignKeyStatement = '\
UPDATE kurssi           \
SET opettaja_id = (     \
    SELECT id           \
    FROM opettaja       \
    WHERE tunnus = ?)   \
WHERE tunnus =?';

    /*
     * luetaan ja "parsitaan" kurssi-tiedot csv-tiedostosta;
     * kun tehty, suoritetaan funktio 'readOpettajatCSV'
     */

    var kurssit;

    csv({delimiter: ';'}).fromFile(`${DataDir}/kurssit.csv`)
            .on('end_parsed', (objArr) => {
                kurssit = objArr;
                log('kurssi-data luettu');
                readOpettajatCSV();
            })
            .on('error', (err) => {
                console.log(err);
            });

    /*
     * luetaan ja "parsitaan" opettaja-tiedot csv-tiedostosta;
     * kun tehty, suoritetaan funktio 'createAndInitializeDatabase'
     */

    var opettajat;

    function readOpettajatCSV() {

        csv({delimiter: ';'}).fromFile(`${DataDir}/opettajat.csv`)
                .on('end_parsed', (objArr) => {
                    opettajat = objArr;
                    log('opettaja-data luettu');
                    createAndInitializeDatabase();
                })
                .on('error', (err) => {
                    console.log(err);
                });

    }

    /*
     * muodostetaan ja alustetaan muistinvarainen tietokanta, johon voidaan 
     * viitata globaalin objektin kautta (global.db)
     */

    function createAndInitializeDatabase() {

        const db = new sqlite3.Database(DatabaseFile);

        db.serialize(function () {

            // tietokantataulut

            db.run(CreateOpettajaStatement);
            db.run(CreateKurssiStatement);

            log('taulut luotu');

            // opettaja-taulun rivit

            const stmtOpe = db.prepare(InsertOpettajaStatement);

            for (var i = 0; i < opettajat.length; i++) {
                var o = opettajat[i];
                stmtOpe.run(o.tunnus, o.sukunimi, o.etunimi);
            }

            stmtOpe.finalize();

            log('opettaja-data tietokannassa');

            // kurssi-taulun rivit

            const stmtKurInsert = db.prepare(InsertKurssiStatement);
            const stmtKurUpdate = db.prepare(UpdateKurssiForeignKeyStatement);

            for (var i = 0; i < kurssit.length; i++) {
                var k = kurssit[i];
                stmtKurInsert.run(k.tunnus, k.nimi, k.laajuus);
                stmtKurUpdate.run(k.opettaja, k.tunnus);
            }

            stmtKurInsert.finalize();
            stmtKurUpdate.finalize();

            log('kurssi-data tietokannassa');

            db.close();
            initSequelize();

        });
    }

} else {
    initSequelize();
}


function initSequelize() {
    
    require('../../models/mappings')(DatabaseFile);
    
}