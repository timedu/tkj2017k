

/* global __dirname */

// TKJ2017k, Tehtävä 2.2

// Nimi: 
// OppNro: 


module.exports = (app) => {

    app.get('/opettajat', function (req, res) {

        res.render('opettajaluettelo');
    });

    app.get('/opettajat/:id', function (req, res) {

        res.render('opettaja');
    });

};



