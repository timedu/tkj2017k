
/* global __dirname */

// TKJ2017k, Tehtävä 2.2

// Nimi: 
// OppNro: 


module.exports = (app) => {

    app.get('/kurssit', function (req, res) {

        res.render('kurssiluettelo');
    });

    app.get('/kurssit/:tunnus', function (req, res) {

        res.render('kurssi');
    });

};

